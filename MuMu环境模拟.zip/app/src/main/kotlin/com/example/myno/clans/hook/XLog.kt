package com.example.myno.clans.hook

import android.util.Log
import java.lang.reflect.Method

/**
 * 日志：logcat + Xposed 日志（LSPosed 管理器 / NPatch / LSPatch 的日志页能看）。
 *
 * ## 两条硬规矩
 *
 * **1）不 import `de.robv.android.xposed.XposedBridge`，改用反射拿。**
 * 在 Xposed API 102 的现代管线里，框架会把 `de.robv.android.xposed.` 开头的类
 * 全部屏蔽掉（VectorModuleClassLoader 直接抛 ClassNotFoundException）。只要字节码里
 * 出现对该类的**静态引用**（包括 lambda 生成的内部类），类校验阶段就可能抛
 * NoClassDefFoundError，把整个现代入口带崩。用 `Class.forName` 字符串查找，
 * 最坏只是拿到 null，永远不会炸。
 *
 * **2）绝不把 Throwable 交给 `Log.e` / `XposedInterface.log`。**
 * 这是 2026-10-09 那次「游戏连续闪退」的教训：NPatch 的
 * `LSPAppComponentFactoryStub.bootstrapOrThrow` 会把模块回调里**出现过的**
 * Throwable 记下来，在 bootstrap 结束时**原样重抛**，于是 `FATAL EXCEPTION: main`，
 * 游戏连启动都过不去。「我们 catch 住了」在 NPatch 下**不等于没事**。
 * 而 `Log.e(tag, msg, tr)` 会把整条栈 `printStackTrace` 到 System.err，
 * 正好给 NPatch 递刀子。
 *
 * 所以 [e] 只把异常**格式化成文字**（前几层 cause + 几个栈帧），
 * 够看清「哪个类、什么异常」，又不会产生任何 Throwable 逃逸。
 * 详见 README_LSPosed.md §12.9。
 */
object XLog {

    private const val TAG = "Clans"

    /** 每个异常最多打几个栈帧，够定位就行，别把 logcat 刷爆 */
    private const val TRACE_FRAMES = 8

    /** 最多往下追几层 cause（NoClassDefFoundError / ClassNotFoundException 这种最关键） */
    private const val TRACE_CAUSES = 3

    /** 传统管线：反射到的 `XposedBridge.log(String)`；拿不到就是 null */
    private val bridgeLog: Method? = try {
        Class.forName("de.robv.android.xposed.XposedBridge").getMethod("log", String::class.java)
    } catch (_: Throwable) {
        null
    }

    /** 现代管线：由 ClansModernModule 注入的 XposedInterface.log 包装 */
    @Volatile
    private var modernLog: ((Int, String, String, Throwable?) -> Unit)? = null

    fun bindModern(logger: (Int, String, String, Throwable?) -> Unit) {
        modernLog = logger
    }

    fun i(msg: String) {
        write(Log.INFO, msg)
    }

    /**
     * 错误日志。
     *
     * ⚠️ `t` **只会被转成文字**，永远不会作为 Throwable 传给框架 —— 理由见类注释第 2 条。
     */
    fun e(msg: String, t: Throwable? = null) {
        write(Log.ERROR, if (t == null) msg else msg + "\n" + brief(t))
    }

    /** 把异常（连同前几层 cause）压成一段多行文字，不带 Throwable 对象 */
    private fun brief(t: Throwable): String = buildString {
        var cur: Throwable? = t
        var depth = 0
        while (cur != null && depth < TRACE_CAUSES) {
            if (depth > 0) append("\nCaused by: ")
            append(cur.toString())
            val frames = cur.stackTrace
            frames.take(TRACE_FRAMES).forEach { append("\n    at ").append(it.toString()) }
            if (frames.size > TRACE_FRAMES) append("\n    ... 还有 ").append(frames.size - TRACE_FRAMES).append(" 帧")
            cur = cur.cause
            depth++
        }
    }

    /** 唯一写日志的地方：logcat + 框架日志页，全部按「纯文字」写 */
    private fun write(priority: Int, msg: String) {
        if (priority >= Log.ERROR) Log.e(TAG, msg) else Log.i(TAG, msg)
        modernLog?.let {
            try {
                it(priority, TAG, msg, null)
            } catch (_: Throwable) {
            }
        }
        bridgeLog?.let {
            try {
                it.invoke(null, "$TAG: $msg")
            } catch (_: Throwable) {
            }
        }
    }
}
