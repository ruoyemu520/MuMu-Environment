package com.example.myno.clans.hook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import java.util.Collections
import java.util.HashMap

/**
 * ============ MuMu 模拟器环境模拟（传统管线 / legacy 82）============
 *
 * 起点：移植独立模块「网易MuMu模拟 1.0」（包名 me.naptila.mumu，作用域 com.netease.sky）。
 * 原模块被 R8 全量混淆，下面第 1、2 组是**反汇编还原**后的等价实现
 * （`Lnaptila/u;->a` 里就是那张假值表：ro.build.id→V417IR、isMuMu/isEmulator→1）。
 *
 * 1) hook `android.os.SystemProperties.get`
 *    —— 只关心 key == "ro.build.id"，命中就把返回值改成 "V417IR"
 *       （"V417IR" 就是网易 MuMu 模拟器的 ro.build.id）
 *
 * 2) hook `org.json.JSONObject.optString`
 *    —— 只关心 key == "isMuMu" / "isEmulator"，命中就返回 "1"
 *
 * 原实现的两个 hook 都在 `beforeHookedMethod` 里直接 `param.setResult(...)`，
 * 也就是**跳过原方法**，本项目保持一致。
 *
 * ------------------------------------------------------------------
 * 3) 为什么光靠 1、2 不够 —— 把网易登录 SDK 的 MuMu 判定链走了一遍
 * ------------------------------------------------------------------
 * 反汇编 `game/classes.dex`（猫和老鼠 832）得到的事实链：
 *
 *   com.netease.mpay.widget.ak.c("ro.build.id", "unknown")
 *       └─ 反射调 android.os.SystemProperties.get(String,String)   ← 第 1 组拦的就是它
 *   com.netease.mpay.widget.ai.c()  = ak.c("ro.build.id","unknown")
 *   com.netease.mpay.widget.ai.d()  = mpay.g.a.contains(ai.c()) || ai.b.containsKey(ai.c())
 *                                     mpay.g.a == Arrays.asList("V417IR","W528JS")
 *   com.netease.mpay.widget.ai.a()  = (g.g && g.d) ? true : ai.d()
 *   com.netease.mpay.g$a.a()        = ai.a() && g$a.b(g$a.a)   // b() 只认 5 或 2
 *   com.netease.mpay.login.a.g()    = f/b/aj.q || ai.a()       // q = qrcode_login_allow_mobile
 *   com.netease.mpay.login.a.d()/h()= ai.a() && ...
 *
 * 也就是说：`ai.a()` 才是「这台设备是 MuMu」的唯一总闸门，
 * 而它读的 ro.build.id 正好被第 1 组伪装掉了 —— 这条链本身是通的。
 *
 * 但「登录页第一屏到底显示哪个页面」是**另一个地方**决定的，
 * 跟 ro.build.id 没关系：`com.netease.mpay.view.a.a.a` 的变体选择器 `u()`：
 *
 *   y$c c = ...;                 // y$c.<init> 里一次性问 login.a.d()/e()/f()
 *   if (c.b) return d.l;         // 索引 11 = LOGIN_DOUYIN
 *   if (c.c) return d.m;         // 索引 12 = LOGIN_DOUYIN_CLOUD
 *   if (c.a) return d.i;         // 索引  8 = LOGIN_QRCODE_LOGIN ← 扫码登录页！
 *   return v();
 *
 *   c.a = login.a.d()   c.b = login.a.e()   c.c = login.a.f()
 *
 * 而 `login.a.d()` 的原体要求**服务端下发的平台表里必须有平台号 17**：
 *
 *   login.a.d() = ai.a() && !aa.f.isEmpty() && aa.f[0].b(ctx) && aa.f[0].a == 17
 *
 * 猫和老鼠这边服务端不给 17 → `d()` 恒 false → `u()` 永远走不到 `d.i`，
 * 于是扫码登录页**根本没机会出现**（这就是「游戏行为没变」的直接原因）。
 * 所以本轮把 `login.a.d()` 直接钉成 true，并把抖音那两个压成 false，
 * 保证 `u()` 落到 `LOGIN_QRCODE_LOGIN`。
 *
 * 另外扫码入口本身还有一道**独立开关**（第 4 组），同样跟 ro.build.id 无关，
 * 纯粹看服务端下发的配置键：
 *
 *   com.netease.mpay.f.b.l.c(HashMap, String)Z   ← 解析 'support_qrcode_login' /
 *                                                    'qrcode_login_allow_mobile'
 *       └─ b(HashMap,String,Z)Z = "1".equals(map.remove(key))
 *   com.netease.mpay.f.b.aj.o = support_qrcode_login
 *   com.netease.mpay.f.b.aj.q = qrcode_login_allow_mobile
 *   com.netease.mpay.f.b.aj.p = disable_qrcode_login_reason
 *
 * 注意 `c`/`a` 是**声明在父类 `l` 上**的（`aj extends j extends l`），
 * 所以 hook 的目标类必须写 `l` —— `XposedHelpers.findAndHookMethod` 走的是
 * `getDeclaredMethod`，挂 `aj` 会直接 NoSuchMethodException。
 * 运行时那句 `invoke-virtual {..}, Lcom/netease/mpay/f/b/aj;->c(..)` 只是
 * DEX 里的引用写法，解析后仍然落到 `l.c` 上，hook 得到。
 *
 * 服务端不给这两个键，客户端就把扫码入口整个藏掉 —— 光伪装机型没用。
 * 所以这里直接把解析结果掰成 true（并在 [QR_FLAG_KEYS] 里列清楚），
 * 并把「禁用原因」清空。
 *
 * 第 5 组（g$a 强制 MuMu 平台）对应 SDK 自己的 FORCE_MUMU_PLATFORM 开关：
 * `SdkNetease.updateForceMuMuPlatform()` 读渠道配置里的 FORCE_MUMU_PLATFORM，
 * 再 `MpayConfig.forceMuMuPlatform(5/2/8)` → `g$a.a(I)` → `sput g$a.a`。
 * 猫和老鼠的渠道配置里没这个配置，`g$a.a` 就一直是初值 0，`b(0)` = false。
 * 真机 MuMu 上这个值通常是 5（PC 平台），所以这里直接钉成 5。
 *
 * ⚠️ **无条件生效，没有开关**（按用户要求：默认开 + 不可关闭）：
 *    这里不读任何偏好值，所以历史版本存过的 `mumu_spoof=false` 不会再生效，
 *    升级后自动恢复伪装，不需要用户去清 clans_module.xml。
 *    面板「杂项」页的「MuMu 环境」只是一行**占位展示**，没有关闭入口
 *    （见 OverlayController.lockedRow 与 Feature.locked）。
 *
 * ⚠️ 这条路径**不挑包名**：作用域内的每个进程都会装上伪装。
 *    原模块本身也是不判包名的（它的 handleLoadPackage 里连包名都没读）。
 *
 * 日志怎么读：
 *   `已 hook xxx` = 方法找到了、hook 挂上了（**不代表游戏真的调用了**）；
 *   `命中 xxx → yyy` = 游戏确实调用了，并且拿到了我们伪造的值。
 *   只有第二类日志能证明伪装生效 —— 每装一次模块这两类都要看一眼。
 *   过滤器：`adb logcat -s Clans | grep -E 'MumuSpoof|已 hook|命中'`
 */
object MumuSpoof {

    /** 游戏判断机型时读的系统属性 */
    const val BUILD_ID_KEY = "ro.build.id"

    /** 网易 MuMu 模拟器的 ro.build.id */
    const val BUILD_ID_VALUE = "V417IR"

    /** 游戏问「是不是模拟器 / 是不是 MuMu」时的答复 */
    const val FAKE_TRUE = "1"

    /** 原模块判定的两个 JSON key */
    private val JSON_KEYS = setOf("isMuMu", "isEmulator")

    /** 网易 SDK 里「允许扫码登录」的两个配置键（见类注释第 3 组） */
    private val QR_FLAG_KEYS = setOf("support_qrcode_login", "qrcode_login_allow_mobile")

    /** 扫码登录被禁用的原因键，必须清空，否则前端会显示「暂不支持扫码」 */
    private const val QR_DISABLE_REASON_KEY = "disable_qrcode_login_reason"

    /**
     * 一个「无参静态方法 → 固定返回值」的伪装点。
     *
     * 全部都是 `static xxx()` 形状的**判定/取值**方法，没有参数，
     * 所以直接 `setResult` 最干净 —— 不去改参数、不去动调用方状态。
     *
     * @param clazz  混淆后的全限定类名（`$` 是内部类分隔符，在 Kotlin 字符串里要写 `\$`）
     * @param method 方法名
     * @param result 要钉死的返回值
     * @param note   人话说明，只进日志
     */
    private class Gate(
        val clazz: String,
        val method: String,
        val result: Any,
        val note: String
    )

    /**
     * 第 3~5 组的伪装点。顺序无所谓，装不上只会打一条「失败（跳过）」。
     *
     * ⚠️ 这里钉死的都是**布尔判定 / 平台编号**，不是业务数据，
     *    所以不会影响登录结果本身，只会让 SDK 认为「我在 MuMu 上」。
     */
    private val GATES = listOf(
        // --- 第 3 组：设备判定（最核心，ai.a() 是所有 MuMu 分支的总闸门）---
        Gate(
            "com.netease.mpay.widget.ai", "a", true,
            "设备判定总闸门：这台机器是 MuMu"
        ),
        Gate(
            "com.netease.mpay.widget.ai", "d", true,
            "机型名匹配（V417IR / W528JS）"
        ),
        Gate(
            "com.netease.mpay.widget.ai", "c", BUILD_ID_VALUE,
            "直接读 ro.build.id —— 连属性 hook 都绕开"
        ),
        Gate(
            "com.netease.mpay.widget.ai", "b", "MuMu",
            "把设备名报成 MuMu"
        ),

        // --- 第 4 组：登录页扫码入口 ---
        Gate(
            "com.netease.mpay.login.a", "g", true,
            "登录页保留扫码登录入口"
        ),
        Gate(
            "com.netease.mpay.login.a", "h", true,
            "登录页扫码能力（服务端标记）"
        ),
        Gate(
            "com.netease.mpay.login.a", "d", true,
            "登录页首选平台 = 扫码（唯一决定登录页变体的开关，见下方 u()）"
        ),
        // 登录页的「变体选择器」是 view/a/a/a;->u()：
        //     y$c c = ...;
        //     if (c.b) return d.l;   // 抖音登录页
        //     if (c.c) return d.m;   // 抖音云登录页
        //     if (c.a) return d.i;   // d.i == LOGIN_QRCODE_LOGIN —— 扫码页！
        //     return v();
        // 而 y$c.a/b/c 就是在 y$c.<init> 里一次性问 login.a.d()/e()/f() 拿到的。
        // 所以只要 d() 为 true、且 e()/f() 不为 true，登录页第一屏就是扫码页。
        // e()/f() 都要求 DouYinProxy.isCloud()，猫和老鼠这边基本恒为 false；
        // 这里显式压成 false 只是为了**保证扫码页的优先级**，
        // 万一游戏真带了抖音云登录，扫码页也不会被它顶掉。
        Gate(
            "com.netease.mpay.login.a", "e", false,
            "让出优先级：抖音云登录页（保证扫码页赢）"
        ),
        Gate(
            "com.netease.mpay.login.a", "f", false,
            "让出优先级：抖音云登录页（保证扫码页赢）"
        ),

        // --- 第 5 组：强制 MuMu 平台（等价 SDK 的 FORCE_MUMU_PLATFORM）---
        Gate(
            "com.netease.mpay.g\$a", "a", true,
            "强制 MuMu 平台判定生效"
        ),
        Gate(
            "com.netease.mpay.g\$a", "b", 5,
            "强制 MuMu 平台编号 5 = PC（SDK 只认 5 和 2）"
        ),

        // --- 第 5 组到此为止 ---
        //
        // ⚠️ 这里**故意不挂** com.netease.ntunisdk.SdkNetease.isConfigMuMuDevice()。
        //    原因是那个类**根本加载不了**：SdkNetease → NeteaseBase → ChannelAAS → SdkBase
        //    在 classes.dex 里都有 class_def，但 SdkBase 实现了一个**插件才有的接口**
        //        Lcom/netease/ntunisdk/base/GamerInterface;
        //    全 APK 六个 dex 都没有它的 class_def（ngplugin 是运行时下载的）。
        //    ART 加载类时要解析整条「父类 + 接口」链，所以
        //        Class.forName("com.netease.ntunisdk.SdkNetease", false, cl)
        //    必抛 NoClassDefFoundError: Failed resolution of:
        //        Lcom/netease/ntunisdk/netease/NeteaseBase;
        //    —— 注意它报的是**父类**名，真正缺的是 GamerInterface，看栈很容易被带偏。
        //
        //    异常本身会被下面的 try/catch 吞掉（日志里只有一行「失败（跳过）」），
        //    但当时那行日志是把 Throwable 一起丢给日志系统的，
        //    而 NPatch 会**记录模块产生的异常**，再在
        //    LSPAppComponentFactoryStub.<clinit> / bootstrapOrThrow 里原样重抛，
        //    于是变成 ExceptionInInitializerError → FATAL EXCEPTION: main →
        //    Process: com.netease.tom 连启动都过不去，悬浮窗自然也不会出来
        //    （它是 onPackageReady 里同一段后面几行的代码）。
        //    实测 2026-10-09：GATES 12 条里 11 条「已 hook」成功、只有这一条「失败」，
        //    模块其余部分（含悬浮窗）全部装完，进程照样被 NPatch 带走。
        //
        //    结论有两条，**缺一不可**：
        //      a) 会抛异常的 hook 一个都不能留 —— 加 Gate 前先用
        //         `python3 tools/check_gate_classes.py --from-source <本文件>` 验一遍，
        //         确认目标类的「父类 + 接口」链在 dex 里 class_def 齐全；
        //      b) 异常一律只记文字、**不交给日志系统**（见 [failSkip] 与 XLog）。
        //    这一路对登录页变体的影响，已经第 4 组的 login.a.d() 覆盖掉了。
    )

    fun install(cl: ClassLoader) {
        // ---- 第 1 组：系统属性（原模块的 hook 之一）----
        // get(String)
        hookSystemProperties(cl, "get", String::class.java)
        // get(String, String) —— 原模块挂的就是这个，也是 ak.c 反射调用的那个
        hookSystemProperties(cl, "get", String::class.java, String::class.java)

        // ---- 第 2 组：JSON（原模块的 hook 之二）----
        // optString(String)
        hookJsonOptString(cl, "optString", String::class.java)
        // optString(String, String) —— 原模块挂的就是这个
        hookJsonOptString(cl, "optString", String::class.java, String::class.java)

        // ---- 第 3~5 组：Java 层闸门 ----
        for (gate in GATES) {
            hookGate(cl, gate)
        }

        // ---- 第 4 组补充：扫码开关是「配置键解析」出来的，得从解析处掰 ----
        hookQrFlags(cl)
    }

    // ------------------------------------------------------------------
    // hook 安装
    // ------------------------------------------------------------------

    private fun hookSystemProperties(cl: ClassLoader, name: String, vararg params: Any) {
        val label = "SystemProperties.$name(${params.joinToString { simple(it) }})"
        try {
            val args = params.toMutableList()
            args.add(object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val key = param.args.getOrNull(0) as? String ?: return
                    if (key != BUILD_ID_KEY) return
                    // 无条件伪装：这里以前有一次 enabled() 判断，现在没有了。
                    // 显式调 setResult，不写 param.result = ...：
                    // api-82 的 MethodHookParam 只有 getResult/setResult 这对方法，
                    // 没有 result 字段，别去赌 Kotlin 的合成属性。
                    logHit(key, BUILD_ID_VALUE)
                    param.setResult(BUILD_ID_VALUE)
                }
            })
            XposedHelpers.findAndHookMethod(
                "android.os.SystemProperties", cl, name, *args.toTypedArray()
            )
            XLog.i("MumuSpoof: 已 hook $label")
        } catch (t: Throwable) {
            failSkip(label, t)
        }
    }

    private fun hookJsonOptString(cl: ClassLoader, name: String, vararg params: Any) {
        val label = "JSONObject.$name(${params.joinToString { simple(it) }})"
        try {
            val args = params.toMutableList()
            args.add(object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val key = param.args.getOrNull(0) as? String ?: return
                    if (key !in JSON_KEYS) return
                    logHit(key, FAKE_TRUE)
                    param.setResult(FAKE_TRUE)
                }
            })
            XposedHelpers.findAndHookMethod("org.json.JSONObject", cl, name, *args.toTypedArray())
            XLog.i("MumuSpoof: 已 hook $label")
        } catch (t: Throwable) {
            failSkip(label, t)
        }
    }

    /**
     * 第 3~5 组：把一个**无参静态方法**的返回值钉死。
     *
     * 先用 `Class.forName(name, false, cl)` 拿类：
     *   · 第三个参数 `false` = 不初始化 —— 类里可能有静态初始化块，
     *     在 hook 阶段就触发它可能反过来调用还没装好的 SDK；
     *   · 传游戏自己的 ClassLoader，否则在模块的 ClassLoader 里根本找不到这些类。
     *
     * `findAndHookMethod(Class, String, Object...)` 这个重载的最后一个参数是回调，
     * 前面是参数类型；无参方法只需要给回调。
     */
    private fun hookGate(cl: ClassLoader, gate: Gate) {
        val label = "${gate.clazz}.${gate.method}() → ${gate.result}（${gate.note}）"
        try {
            val cls = Class.forName(gate.clazz, false, cl)
            XposedHelpers.findAndHookMethod(cls, gate.method, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    logHit("${gate.clazz}.${gate.method}", gate.result.toString())
                    param.setResult(gate.result)
                }
            })
            XLog.i("MumuSpoof: 已 hook $label")
        } catch (t: Throwable) {
            failSkip(label, t)
        }
    }

    /**
     * 第 4 组的真正开关：扫码登录能力是从服务端配置里解析出来的，
     * 解析器是 `com.netease.mpay.f.b.l`：
     *
     *   c(HashMap, String)Z  = b(map, key, false)
     *   b(HashMap, String, Z)Z  = "1".equals(map.remove(key))
     *   a(HashMap, String)Ljava/lang/String;  = 取值，缺省返回 null
     *
     * 所以只要在 `c` 里对那两个键直接回 true，
     * `aj.o`(support_qrcode_login) 和 `aj.q`(qrcode_login_allow_mobile) 就都是 true。
     *
     * 注意 `c` 只认这两个键、其它键照常走原方法（返回 NOT_HANDLED 那套逻辑
     * 在 legacy 里就是「不调 setResult」）—— 别写成无脑 return true，
     * 同名方法还被用来解析别的几十个开关。
     */
    private fun hookQrFlags(cl: ClassLoader) {
        val className = "com.netease.mpay.f.b.l"

        // c(HashMap, String)Z —— 布尔型配置键
        val boolLabel = "$className.c(HashMap, String) → ${QR_FLAG_KEYS.joinToString()}"
        try {
            val cls = Class.forName(className, false, cl)
            XposedHelpers.findAndHookMethod(
                cls, "c", HashMap::class.java, String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val key = param.args.getOrNull(1) as? String ?: return
                        if (key !in QR_FLAG_KEYS) return
                        logHit("$className.c:$key", "true")
                        param.setResult(true)
                    }
                }
            )
            XLog.i("MumuSpoof: 已 hook $boolLabel")
        } catch (t: Throwable) {
            failSkip(boolLabel, t)
        }

        // a(HashMap, String)String —— 字符串型配置键（清掉「不支持扫码」的原因）
        val strLabel = "$className.a(HashMap, String)[$QR_DISABLE_REASON_KEY] → 空串"
        try {
            val cls = Class.forName(className, false, cl)
            XposedHelpers.findAndHookMethod(
                cls, "a", HashMap::class.java, String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val key = param.args.getOrNull(1) as? String ?: return
                        if (key != QR_DISABLE_REASON_KEY) return
                        logHit("$className.a:$key", "（清空）")
                        param.setResult("")
                    }
                }
            )
            XLog.i("MumuSpoof: 已 hook $strLabel")
        } catch (t: Throwable) {
            failSkip(strLabel, t)
        }
    }

    /**
     * 给日志用的参数类型名。传进来的是 `Class<*>`（类型）或字符串（方法名），
     * 分别打印成 `String` / `get`。
     *
     * 注意是 `p.toString()` 而不是 `String.valueOf(p)`：
     * `String.valueOf` 是 java.lang.String 的**静态方法**，Kotlin 里不可见
     * （`String` 被映射成 kotlin.String，只暴露伴生对象上的那几个成员），
     * 写了会报 "Unresolved reference 'valueOf'"。
     * Kotlin 的 `Any?.toString()` 对 null 同样返回 "null"，语义一致。
     */
    private fun simple(p: Any?): String = (p as? Class<*>)?.simpleName ?: p.toString()

    /**
     * hook 装不上时的统一出口。
     *
     * ⚠️ **故意不把 Throwable 交给 XLog.e / Log.e**，只把 `toString()` 拼进文字里。
     *    原因见 [GATES] 末尾：NPatch 会记录模块产生的异常并在 bootstrap 阶段重抛，
     *    「我们 catch 住了」在 NPatch 下**不等于没事**，所以连「把异常递给日志系统」
     *    这一步都不做。保留 `toString()` 已经足够看清是什么异常、缺了哪个类。
     *
     * 注意：这个函数只是**最后一道保险**。真正保证不抛异常的是
     * `tools/check_gate_classes.py`（加 Gate 前先跑它验「父类 + 接口」链）。
     */
    private fun failSkip(label: String, t: Throwable) {
        XLog.e("MumuSpoof: hook $label 失败（跳过）：$t")
    }

    // ------------------------------------------------------------------
    // 命中打点
    // ------------------------------------------------------------------

    /**
     * 已经打过日志的 key。**每个 key 只打一次**，避免热方法刷屏
     * （`JSONObject.optString` 一秒可能被调几千次）。
     *
     * 用 `Collections.synchronizedSet` 包一层：hook 回调可能来自任意线程，
     * 而 `Set.add` 的返回值正好就是「我是不是第一个加进去的」，
     * 天然就是「只打一次」的判据，不需要额外的锁和标记变量。
     */
    private val hitLogged: MutableSet<String> = Collections.synchronizedSet(mutableSetOf<String>())

    private fun logHit(key: String, value: String) {
        if (hitLogged.add(key)) {
            XLog.i("MumuSpoof: 命中 $key → $value（伪装被游戏读到了）")
        }
    }
}
