package com.example.myno.clans

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.myno.clans.hook.Config

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNotificationPermission()
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = BG) {
                    var selectedTab by remember { mutableStateOf(0) }
                    ModuleScreen(
                        selectedTab = selectedTab,
                        onTabChange = { selectedTab = it },
                        onPreview = { startPreview() },
                        onStopPreview = { stopPreview() },
                        onOpenGame = { launchApp(Config.TARGET_PACKAGES.first()) },
                        onOpenManager = { openManager() },
                        onGrantGame = { openOverlaySettingsForGame() }
                    )
                }
            }
        }
    }

    private fun startPreview() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先允许 mumu环境模拟显示在其他应用上层", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (_: Throwable) { }
            return
        }
        val intent = Intent(this, FloatingService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            Toast.makeText(this, "悬浮球已启动，点击悬浮球打开面板", Toast.LENGTH_SHORT).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "启动预览失败：${t.message ?: "未知错误"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopPreview() {
        stopService(Intent(this, FloatingService::class.java))
        Toast.makeText(this, "悬浮窗预览已停止", Toast.LENGTH_SHORT).show()
    }

    private fun launchApp(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            Toast.makeText(this, "没找到目标应用：$pkg", Toast.LENGTH_LONG).show()
            return
        }
        try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (t: Throwable) { Toast.makeText(this, "启动失败：${t.message}", Toast.LENGTH_LONG).show() }
    }

    private fun openManager() {
        for (pkg in listOf("org.lsposed.lspatch", "org.lsposed.manager")) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return }
                catch (_: Throwable) { }
            }
        }
        Toast.makeText(this, "没有找到 LSPatch / LSPosed 管理器", Toast.LENGTH_LONG).show()
    }

    private fun openOverlaySettingsForGame() {
        val pkg = Config.TARGET_PACKAGES.first()
        try {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg")))
        } catch (_: Throwable) {
            Toast.makeText(this, "请到系统设置中为目标游戏开启悬浮窗权限", Toast.LENGTH_LONG).show()
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        try { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001) } catch (_: Throwable) { }
    }
}

private val BG = Color(0xFF080B13)
private val SURFACE = Color(0xFF111622)
private val RAISED = Color(0xFF1A2232)
private val BORDER = Color(0xFF30394D)
private val TEXT = Color(0xFFF5F5FA)
private val TEXT_2 = Color(0xFFD7DCE8)
private val MUTED = Color(0xFF8F9AB0)
private val PINK = Color(0xFFFF79D2)
private val PINK_DIM = Color(0xFF30203C)
private val BLUE = Color(0xFF8AA8FF)
private val BLUE_DIM = Color(0xFF1B2742)
private val GREEN = Color(0xFF8BE0BC)

@Composable
private fun ModuleScreen(
    selectedTab: Int,
    onTabChange: (Int) -> Unit,
    onPreview: () -> Unit,
    onStopPreview: () -> Unit,
    onOpenGame: () -> Unit,
    onOpenManager: () -> Unit,
    onGrantGame: () -> Unit
) {
    Column(Modifier.fillMaxSize().background(BG)) {
        Column(
            modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (selectedTab == 0) {
                HeroHeader()
                Panel("悬浮窗设置") {
                    Text("点击任一模式可启动悬浮窗，然后在悬浮窗的「设置」页应用背景。", color = MUTED, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    ModeCard("☾", "深色模式", "使用深色渐变背景", BLUE, BLUE_DIM, onPreview)
                    Spacer(Modifier.height(10.dp))
                    ModeCard("▧", "网页图片模式", "从网页获取图片作为背景", PINK, PINK_DIM, onPreview)
                }
                Panel("本机预览") {
                    Text("在桌面查看悬浮窗外观，不会修改游戏数据。", color = MUTED, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    ActionButton("开始预览悬浮窗", true, onPreview)
                    Spacer(Modifier.height(8.dp))
                    ActionButton("停止预览", false, onStopPreview)
                }
            } else {
                HeroHeader(compact = true)
                Panel("设置与工具") {
                    Text("这里是应用自身的快捷设置。背景模式请在悬浮窗面板中切换。", color = MUTED, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    ActionButton("启动悬浮窗预览", true, onPreview)
                    Spacer(Modifier.height(8.dp))
                    ActionButton("停止悬浮窗预览", false, onStopPreview)
                    Spacer(Modifier.height(8.dp))
                    ActionButton("打开猫和老鼠", false, onOpenGame)
                    Spacer(Modifier.height(8.dp))
                    ActionButton("打开 LSPatch / LSPosed 管理器", false, onOpenManager)
                    Spacer(Modifier.height(8.dp))
                    ActionButton("目标游戏悬浮窗权限", false, onGrantGame)
                }
                Panel("模块信息") {
                    InfoRow("模块名称", "mumu环境模拟")
                    InfoRow("备注", "mumu环境模拟by ClcccAln_22")
                    InfoRow("目标应用", "com.netease.tom")
                    InfoRow("注入方式", "游戏进程内悬浮窗")
                }
            }
        }
        BottomNavigation(selectedTab = selectedTab, onTabChange = onTabChange)
    }
}

@Composable
private fun HeroHeader(compact: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Color(0xFF171522)).padding(horizontal = 14.dp, vertical = if (compact) 14.dp else 22.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = R.drawable.mumu_app_image),
            contentDescription = "应用图片",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(if (compact) 64.dp else 82.dp).clip(RoundedCornerShape(18.dp))
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("mumu环境模拟", color = TEXT, fontSize = if (compact) 20.sp else 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("mumu环境模拟by ClcccAln_22", color = TEXT_2, fontSize = 12.sp)
            if (!compact) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Chip("Xposed 模块", PINK, PINK_DIM)
                    Chip("双管线", GREEN, Color(0xFF19352F))
                }
            }
        }
    }
}

@Composable
private fun ModeCard(iconText: String, title: String, subtitle: String, accent: Color, accentBg: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(RAISED.copy(alpha = 0.72f))
            .border(BorderStroke(1.dp, BORDER), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(accentBg), contentAlignment = Alignment.Center) {
            Text(iconText, color = accent, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TEXT, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = MUTED, fontSize = 11.sp)
        }
        Text("›", color = accent, fontSize = 30.sp)
    }
}

@Composable
private fun BottomNavigation(selectedTab: Int, onTabChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(Color(0xFF0C101A)).navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem("⌂", "主页", selectedTab == 0) { onTabChange(0) }
        NavItem("⚙", "设置", selectedTab == 1) { onTabChange(1) }
    }
}

@Composable
private fun NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier.width(112.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, color = if (selected) PINK else MUTED, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(label, color = if (selected) PINK else MUTED, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Box(Modifier.width(if (selected) 28.dp else 0.dp).height(3.dp).clip(CircleShape).background(PINK))
    }
}

@Composable
private fun Chip(text: String, fg: Color, bg: Color) {
    Box(Modifier.clip(RoundedCornerShape(7.dp)).background(bg).border(BorderStroke(1.dp, fg.copy(alpha = 0.4f)), RoundedCornerShape(7.dp)).padding(horizontal = 8.dp, vertical = 5.dp)) {
        Text(text, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun Panel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SURFACE)
            .border(BorderStroke(1.dp, BORDER), RoundedCornerShape(16.dp)).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(PINK))
            Spacer(Modifier.width(9.dp))
            Text(title, color = TEXT, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun InfoRow(key: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
        Text(key, color = MUTED, fontSize = 12.sp, modifier = Modifier.width(86.dp))
        Text(value, color = TEXT_2, fontSize = 12.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun ActionButton(text: String, primary: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp))
            .background(if (primary) Color(0xFF8D2D77) else RAISED)
            .border(BorderStroke(1.dp, if (primary) PINK.copy(alpha = 0.6f) else BORDER), RoundedCornerShape(11.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = TEXT, fontSize = 13.sp, fontWeight = if (primary) FontWeight.Bold else FontWeight.Medium)
    }
}
