#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
加 Gate 之前先跑这个：检查目标类**能不能被加载**。

为什么需要它
------------
MuMuSpoof / ModernMumuSpoof 里的 GATES 是靠 `Class.forName(name, false, gameCL)`
找类的。只要这个调用抛异常（哪怕我们 try/catch 吞掉了），
NPatch 的 `LSPAppComponentFactoryStub.bootstrapOrThrow` 就会把异常记下来、
在 bootstrap 结束时重抛 → `FATAL EXCEPTION: main` → 游戏起不来、悬浮窗也不出来。

而 `Class.forName` 失败**不等于「这个类不在 APK 里」**：
ART 加载一个类时要先解析它整条「父类 + 接口」链，
链上**任何一个**类缺 class_def 都会让最外面那个类加载失败。
更坑的是报错信息里写的是**父类**的名字（2026-10-09 那次就报
`Failed resolution of: Lcom/netease/ntunisdk/netease/NeteaseBase;`，
真正缺的其实是 `Lcom/netease/ntunisdk/base/GamerInterface;`）。

所以这里做的事就是把闭包算出来，把真正缺失的类名指出来。

用法
----
    # 先准备 dex（从游戏 APK 里取，或用 NPatch 的 origin.apk）
    unzip -o 猫和老鼠.apk 'classes*.dex' -d game/

    python3 tools/check_gate_classes.py \
        'Lcom/netease/mpay/widget/ai;' \
        'Lcom/netease/mpay/login/a;' \
        'Lcom/netease/mpay/g$a;' \
        'Lcom/netease/mpay/f/b/l;'

    # dex 不在 ./game 就用 --dex-dir
    python3 tools/check_gate_classes.py --dex-dir /sdcard/game 'Lcom/.../Foo;'

也可以不传类名，直接读源码文件里的 GATES，把类名全抠出来跑一遍：

    python3 tools/check_gate_classes.py --from-source \
        app/src/main/kotlin/com/example/myno/clans/hook/MumuSpoof.kt

退出码：全 OK = 0，有 FAIL = 1（方便接到 gradle / 手动流水线里）。
"""
import argparse
import os
import re
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dexdump import Dex  # noqa: E402

# 只检查这些前缀的类：Android 框架类（Ljava/...）没必要查，
# 而且它们本来就不在游戏 dex 里。
DEFAULT_PREFIX = 'Lcom/netease/'


def load_dex(dex_dir):
    """返回 (defs, ifaces)：类名 -> 父类、类名 -> 接口列表"""
    if not os.path.isdir(dex_dir):
        sys.exit(f'找不到 dex 目录：{dex_dir}\n'
                 f'先把游戏的 classes*.dex 解出来，例如：\n'
                 f"  unzip -o 猫和老鼠.apk 'classes*.dex' -d {dex_dir}")

    files = sorted(
        (f for f in os.listdir(dex_dir) if re.fullmatch(r'classes\d*\.dex', f)),
        key=lambda f: (len(f), f),  # classes.dex 排最前
    )
    if not files:
        sys.exit(f'{dex_dir} 里没有 classes*.dex')

    defs, ifaces = {}, {}
    for name in files:
        path = os.path.join(dex_dir, name)
        data = open(path, 'rb').read()
        dx = Dex(data)
        for c in dx.classes():
            defs[c['name']] = c['super']

        # class_def_item：32 字节，第 3 个 u4 是 interfaces_off
        for i in range(dx.class_defs_size):
            b = dx.class_defs_off + 32 * i
            cls_idx, _acc, _sup_idx, if_off = struct.unpack('<IIII', data[b:b + 16])
            lst = []
            if if_off:
                size = struct.unpack('<I', data[if_off:if_off + 4])[0]
                for k in range(size):
                    ti = struct.unpack(
                        '<H', data[if_off + 4 + 2 * k:if_off + 6 + 2 * k]
                    )[0]
                    lst.append(dx.type(ti))
            ifaces[dx.type(cls_idx)] = lst

        print(f'  读入 {name}：{len(defs)} 个 class_def（累计）', file=sys.stderr)
    return defs, ifaces


def check(root, defs, ifaces, prefix=DEFAULT_PREFIX):
    """返回 root 的「父类 + 接口」闭包里所有缺 class_def 的类"""
    bad, seen, stack = [], set(), [root]
    while stack:
        c = stack.pop()
        if c in seen or not c.startswith(prefix):
            continue
        seen.add(c)
        if c not in defs:          # ★ 这种类一碰 Class.forName 就抛
            bad.append(c)
            continue
        sup = defs.get(c)
        if sup and sup != 'Ljava/lang/Object;':
            stack.append(sup)
        stack.extend(ifaces.get(c, []))
    return bad


def gates_from_source(paths):
    """从 Kotlin 源码里抠出 GATES 的类名（Gate("com.a.B", ...) 的第一个参数）"""
    names = []
    pat = re.compile(r'Gate\(\s*"([^"]+)"')
    for p in paths:
        src = open(p, encoding='utf-8').read()
        for m in pat.finditer(src):
            # Kotlin 字符串里 `$` 必须写成 `\$`（内部类分隔符），先还原
            raw = m.group(1).replace('\\$', '$')
            names.append('L' + raw.replace('.', '/') + ';')
    # 去重但保持顺序
    seen, out = set(), []
    for n in names:
        if n not in seen:
            seen.add(n)
            out.append(n)
    return out


def main():
    ap = argparse.ArgumentParser(description='检查 Gate 目标类的父类+接口链是否完整')
    ap.add_argument('classes', nargs='*', help='类描述符，如 Lcom/netease/mpay/widget/ai;')
    ap.add_argument('--dex-dir', default='game', help='classes*.dex 所在目录（默认 ./game）')
    ap.add_argument('--from-source', nargs='+', metavar='KT',
                    help='从这些 Kotlin 源文件里抠 GATES 的类名')
    ap.add_argument('--all-prefixes', action='store_true',
                    help='连非 Lcom/netease/ 的类也一起查')
    args = ap.parse_args()

    targets = list(args.classes)
    if args.from_source:
        targets += gates_from_source(args.from_source)

    if not targets:
        ap.error('至少给一个类名，或用 --from-source 指定源码文件')

    print(f'dex 目录：{args.dex_dir}', file=sys.stderr)
    defs, ifaces = load_dex(args.dex_dir)

    prefix = '' if args.all_prefixes else DEFAULT_PREFIX
    failed = 0
    for root in targets:
        bad = check(root, defs, ifaces, prefix)
        if bad:
            failed += 1
            print(f'FAIL {root}')
            for b in bad:
                print(f'       缺: {b}')
        else:
            print(f'OK   {root}')

    print(f'\n共 {len(targets)} 个，{failed} 个有问题。', file=sys.stderr)
    if failed:
        print('⚠️ 有问题的类**不要**加进 GATES：Class.forName 会抛异常，'
              'NPatch 会把进程带走。', file=sys.stderr)
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
