#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 MainActivity.kt 的 Compose 布局**按 dp 逐块重画**成一张 PNG 预览图。

为什么要这个：这台设备没有 JDK / Android SDK，编译不了 APK，
所以没法直接看到界面长什么样。这个脚本按 Compose 代码里的真实
尺寸（dp）、圆角、描边、配色重画一遍，用来核对视觉风格。

文字没有字体可渲染，统一画成**圆角条**（骨架样式）：
条的粗细/长短对应真实文字的字号与宽度，所以版式是准的。
"""
import zlib, struct, sys

# ---------------- 配色（必须与 MainActivity.kt 里的常量逐一对应）----------------
BG         = (0x15,0x15,0x17)
SURFACE    = (0x23,0x23,0x24)
RAISED     = (0x2C,0x2C,0x2E)
BORDER     = (0x3C,0x3C,0x3D)
LINE       = (0x2C,0x2C,0x2E)
TEXT       = (0xF9,0xFA,0xFB)
TEXT_2     = (0xCF,0xD3,0xD6)
MUTED      = (0xAD,0xB2,0xB8)
ORANGE     = (0xDD,0x86,0x29)
ORANGE_DIM = (0x3A,0x2C,0x18)
BLUE       = (0x7A,0xAA,0xFF)
BLUE_DIM   = (0x1B,0x27,0x40)
RED        = (0xF2,0x5A,0x5A)
GREEN      = (0x4C,0xC3,0x8A)
GREEN_DIM  = (0x1E,0x33,0x28)
# 悬浮窗的粉色（**这次没动**，只在图末做对照）
PINK       = (0xFF,0x82,0xBE)

SCALE = 3          # 1dp = 3px（xxhdpi 附近的密度）
W_DP  = 360
H_DP  = 1160

W, H = W_DP*SCALE, H_DP*SCALE
buf = bytearray(bytes(BG)*(W*H))

def px(x, y, c):
    if 0 <= x < W and 0 <= y < H:
        i = (y*W + x)*3
        buf[i] = c[0]; buf[i+1] = c[1]; buf[i+2] = c[2]

def rrect(x, y, w, h, c, r=0):
    """填圆角矩形（参数单位 dp，内部按 SCALE 放大）"""
    X, Y, Wd, Hd = int(x*SCALE), int(y*SCALE), int(w*SCALE), int(h*SCALE)
    R = int(r*SCALE)
    for yy in range(Y, Y+Hd):
        for xx in range(X, X+Wd):
            if R > 0:
                dx = dy = 0
                if xx < X+R:          dx = X+R-xx
                elif xx >= X+Wd-R:    dx = xx-(X+Wd-R-1)
                if yy < Y+R:          dy = Y+R-yy
                elif yy >= Y+Hd-R:    dy = yy-(Y+Hd-R-1)
                if dx*dx + dy*dy > R*R: continue
            px(xx, yy, c)

def border(x, y, w, h, c, r=0, t=1):
    """圆角描边：填一层描边色，再用底色盖回内部由调用方处理（这里直接画两圈）"""
    rrect(x, y, w, h, c, r)
    rrect(x+t, y+t, w-2*t, h-2*t, BG, max(0, r-t))

def card(x, y, w, h):
    rrect(x, y, w, h, SURFACE, 12)
    # 1dp 描边（先画边框色再盖内部）
    rrect(x, y, w, h, BORDER, 12)
    rrect(x+1, y+1, w-2, h-2, SURFACE, 11)

def bar(x, y, w, h, c, r=None):
    """文字骨架条"""
    rrect(x, y, w, h, c, h/2 if r is None else r)

# ==================== 开始画 ====================
Y = 22.0
X0 = 18.0
CW = W_DP - 2*X0          # 卡片宽 = 324dp

# ---- Header：左侧 4x30 橙色竖条 + 标题/副标题 ----
rrect(X0, Y, 4, 30, ORANGE, 2)
bar(X0+14, Y+1,  58, 10, TEXT, 2)      # "Clans"  24sp Bold
bar(X0+14, Y+18, 104, 5, MUTED)        # 副标题 11sp

Y += 30 + 16

# ---- 状态 chips：3 个 ----
def chip(x, y, w, fg, bg):
    rrect(x, y, w, 18, bg, 6)
    rrect(x, y, w, 18, fg, 6)
    rrect(x+1, y+1, w-2, 16, bg, 5)
    # 内部文字（10sp）
    bar(x+8, y+6.5, w-16, 5, fg)

chip(X0,      Y, 62, ORANGE, ORANGE_DIM)   # "legacy 82"
chip(X0+70,   Y, 70, BLUE,   BLUE_DIM)     # "modern 102"
chip(X0+148,  Y, 74, GREEN,  GREEN_DIM)    # "双管线就绪"
Y += 18 + 18

def panel_title(x, y):
    rrect(x, y, 3, 13, ORANGE, 2)
    bar(x+11, y+3, 46, 7, TEXT, 2)          # 标题 13sp Bold
    return y + 13 + 10

def info_row(x, y, kw, vw, hint=None):
    """InfoRow：左键(11sp) + 右值(11sp)，hint 额外一行(10sp)"""
    bar(x, y+3, kw, 5, MUTED)
    bar(x+78, y+3, vw, 5, TEXT_2)
    y += 4 + 10 + 4
    if hint:
        bar(x+78, y+1, hint, 4, MUTED)
        y += 1 + 8 + 1
    return y

def ghost_btn(x, y, w, label_w):
    rrect(x, y, w, 35, RAISED, 9)
    rrect(x, y, w, 35, BORDER, 9)
    rrect(x+1, y+1, w-2, 33, RAISED, 8)
    bar(x+(w-label_w)/2, y+15, label_w, 6, TEXT_2)

def primary_btn(x, y, w, label_w):
    rrect(x, y, w, 35, ORANGE, 9)
    bar(x+(w-label_w)/2, y+15, label_w, 6, (0x15,0x15,0x17))

# ---- Panel 1: 模块信息 ----
PAD = 14.0
p1_h = 14 + 13 + 10 + (4+10+4)*4 + (4+10+4+10)*2 + 14
card(X0, Y, CW, p1_h)
cy = panel_title(X0+PAD, Y+PAD)
cy = info_row(X0+PAD, cy, 44, 96)                  # 模块类型
cy = info_row(X0+PAD, cy, 44, 88)                  # 目标应用
cy = info_row(X0+PAD, cy, 44, 120)                 # 主 Activity
cy = info_row(X0+PAD, cy, 44, 132)                 # 注入方式
cy = info_row(X0+PAD, cy, 48, 92, hint=104)        # 旧框架入口 + hint
cy = info_row(X0+PAD, cy, 48, 122, hint=118)       # 新框架入口 + hint
Y += p1_h + 12

# ---- Panel 2: 使用步骤 ----
p2_h = 14 + 13 + 10 + 3*(4+11+4) + 10 + 1 + 10 + 2*12 + 14
card(X0, Y, CW, p2_h)
cy = panel_title(X0+PAD, Y+PAD)
for i, w in enumerate((150, 158, 168)):
    rrect(X0+PAD, cy+4, 18, 11, ORANGE_DIM, 5.5)   # 序号圆点 18dp（这里压扁成 11dp 示意）
    rrect(X0+PAD, cy+4, 18, 11, ORANGE, 5.5)
    rrect(X0+PAD+1, cy+5, 16, 9, ORANGE_DIM, 4.5)
    bar(X0+PAD+4.5, cy+7.5, 9, 4, ORANGE)
    bar(X0+PAD+27, cy+6, w, 5, TEXT_2)
    cy += 4+11+4
cy += 10
bar(X0+PAD, cy, CW-2*PAD, 1, LINE, 0)              # Divider
cy += 10
bar(X0+PAD, cy,   220, 5, MUTED)
bar(X0+PAD, cy+12, 168, 5, MUTED)
Y += p2_h + 12

# ---- Panel 3: 快捷入口 ----
p3_h = 14 + 13 + 10 + 35 + 8 + 35 + 8 + 35 + 14
card(X0, Y, CW, p3_h)
cy = panel_title(X0+PAD, Y+PAD)
primary_btn(X0+PAD, cy, CW-2*PAD, 48); cy += 35+8
ghost_btn(X0+PAD, cy, CW-2*PAD, 132);  cy += 35+8
ghost_btn(X0+PAD, cy, CW-2*PAD, 118)
Y += p3_h + 12

# ---- Panel 4: 本机预览 ----
p4_h = 14 + 13 + 10 + 12 + 10 + 35 + 8 + 35 + 14
card(X0, Y, CW, p4_h)
cy = panel_title(X0+PAD, Y+PAD)
bar(X0+PAD, cy, 196, 5, MUTED); cy += 12+10
ghost_btn(X0+PAD, cy, CW-2*PAD, 108); cy += 35+8
ghost_btn(X0+PAD, cy, CW-2*PAD, 64)
Y += p4_h + 12

# ---- Panel 5: 排错 ----
p5_h = 14 + 13 + 10 + 4*(11 + 2 + 2*11) + 3*10 + 14
card(X0, Y, CW, p5_h)
cy = panel_title(X0+PAD, Y+PAD)
for col, tw, bl in ((RED, 96, 150), (BLUE, 62, 142), (ORANGE, 74, 132), (MUTED, 92, 176)):
    rrect(X0+PAD, cy+5, 6, 6, col, 3)
    bar(X0+PAD+14, cy+4, tw, 5, TEXT_2)            # 小标题 11sp
    bar(X0+PAD+14, cy+13, bl, 4, MUTED)            # 正文 10sp
    bar(X0+PAD+14, cy+22, bl*0.62, 4, MUTED)
    cy += 11+2+2*11 + 10
Y += p5_h + 22

# ---- 页脚 ----
bar(X0, Y, 178, 4, MUTED)
Y += 4 + 24

# ---- 图末：悬浮窗粉色（未改动）对照条 ----
rrect(X0, Y, 4, 14, PINK, 2)
bar(X0+14, Y+4.5, 150, 5, MUTED)
Y += 14 + 14

REAL_H = int(Y*SCALE)
print('内容高度 %d dp → %d px，画布 %d px' % (int(Y), REAL_H, H))
if REAL_H > H:
    raise SystemExit('画布太矮，加高 H_DP')

# ---------------- 输出 PNG ----------------
raw = bytearray()
for y in range(H):
    raw.append(0)
    raw += buf[y*W*3:(y+1)*W*3]

def chunk(tag, data):
    c = struct.pack('>I', len(data)) + tag + data
    return c + struct.pack('>I', zlib.crc32(tag+data) & 0xffffffff)

png = b'\x89PNG\r\n\x1a\n'
png += chunk(b'IHDR', struct.pack('>IIBBBBB', W, H, 8, 2, 0, 0, 0))
png += chunk(b'IDAT', zlib.compress(bytes(raw), 9))
png += chunk(b'IEND', b'')

out = sys.argv[1] if len(sys.argv) > 1 else 'ui_mock.png'
open(out, 'wb').write(png)
print('已生成 %s  (%dx%d, %.1f KB)' % (out, W, H, len(png)/1024))
