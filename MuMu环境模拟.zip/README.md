# mumu环境模拟

项目备注：mumu环境模拟by ClcccAln_22

这是一个 Android 项目，源码主要使用 Kotlin，界面包含 Jetpack Compose 相关实现，并包含 Xposed/LSPosed 模块相关配置。

> **当前版本说明**：此仓库按当前备份整理，尚未在干净环境中验证完整构建流程。依赖文件、Gradle 版本和运行时功能可能需要根据实际开发环境进一步调整。

## 项目结构

- `app/src/main/kotlin/`：应用、悬浮窗、模块与相关逻辑源码
- `app/src/main/res/`：界面资源与图片资源
- `app/src/main/assets/xposed_init`：模块入口配置
- `app/src/main/resources/META-INF/xposed/`：Xposed 模块元数据
- `gradle/`：Gradle Wrapper 与版本目录配置

## 构建

推荐使用 AndroidIDE 或兼容的 Android/Gradle 开发环境打开项目。首次构建前，请检查 Android Gradle Plugin、Gradle Wrapper 版本是否兼容，并确认 `app/build.gradle` 所引用的本地依赖文件均已提供。

本仓库当前未声明“已成功编译”或“已通过设备测试”。

## 功能状态

当前版本包含主界面、悬浮窗和网页图片相关实现。具体功能是否在目标设备上正常运行，需要实际安装与测试。

## 发布说明

本仓库不附带开源许可证。公开前，请确认你拥有源码、图片和其他资源的公开发布权限；如需允许他人复制、修改或分发，请在确认权利后选择并添加合适的许可证。
