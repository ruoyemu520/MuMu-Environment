package com.example.myno.clans.overlay

import android.content.Context
import android.content.res.AssetManager
import android.content.res.Resources
import com.example.myno.clans.hook.Config
import com.example.myno.clans.hook.XLog
import java.io.File

/**
 * 取「模块 APK 自己的资源」。
 *
 * 为什么必须这么做：悬浮窗是在**目标游戏进程**里画的，
 * 如果直接 setImageResource(R.drawable.xuanfu)，这个 id 会被拿去游戏的资源表里解析，
 * 轻则加载到一张不相关的游戏图片，重则 Resources.NotFoundException 直接崩。
 *
 * 按可靠性依次尝试，全失败就返回 null，上层会退化成纯色/渐变外观（绝不崩）：
 *   1) 预览模式：就跑在模块自己的 App 进程里，直接用 app.resources
 *   2) createPackageContext：模块 App 被单独安装了（LSPosed 常规用法）
 *   3) AssetManager.addAssetPath(模块 APK)：模块被内嵌、没单独安装时（LSPatch/NPatch）
 *      路径来自 modern 的 getModuleApplicationInfo().sourceDir 或 legacy 的 initZygote
 *   4) 传统管线的 XModuleResources —— **反射**调用，API 102 下会拿不到类，直接跳过
 */
object ModuleResources {

    @Volatile
    private var cached: Resources? = null

    fun resolve(app: Context): Resources? {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val r = tryResolve(app)
            cached = r
            return r
        }
    }

    private fun tryResolve(app: Context): Resources? {
        // 1) 预览模式：就跑在模块自己的 App 进程里，直接用自己的资源
        if (app.packageName == Config.MODULE_PACKAGE) {
            XLog.i("模块资源：使用自身 resources")
            return app.resources
        }

        // 2) 模块 App 仍然安装着（LSPosed 常规用法）
        try {
            val res = app.createPackageContext(
                Config.MODULE_PACKAGE,
                Context.CONTEXT_IGNORE_SECURITY
            ).resources
            XLog.i("模块资源：createPackageContext 成功")
            return res
        } catch (t: Throwable) {
            XLog.e("模块资源：createPackageContext 失败", t)
        }

        // 3) 直接从模块 APK 造 Resources（内嵌模式；现代管线的标准做法）
        val apk = Config.moduleApkPath ?: Config.modulePath
        if (!apk.isNullOrEmpty()) {
            val res = tryFromApk(app, apk)
            if (res != null) return res
        }

        // 4) 传统管线的兜底（反射，现代管线会 ClassNotFoundException → 跳过）
        if (!Config.modernApi) {
            val path = Config.modulePath
            if (!path.isNullOrEmpty()) {
                try {
                    val cls = Class.forName("android.content.res.XModuleResources")
                    val m = cls.getMethod(
                        "createInstance",
                        String::class.java,
                        Class.forName("android.content.res.XResources")
                    )
                    val res = m.invoke(null, path, null) as? Resources
                    if (res != null) {
                        XLog.i("模块资源：XModuleResources 成功 path=$path")
                        return res
                    }
                } catch (t: Throwable) {
                    XLog.e("模块资源：XModuleResources 失败", t)
                }
            }
        }

        XLog.e("模块资源：全部失败，悬浮窗将使用兜底外观（功能不受影响）")
        return null
    }

    /**
     * 用 AssetManager.addAssetPath 加载模块 APK 里的资源。
     * addAssetPath 是隐藏 API，但在 LSPosed/NPatch 环境里 hidden API 限制已被放开；
     * 拿不到就返回 null，交给上层兜底。
     */
    private fun tryFromApk(app: Context, apkPath: String): Resources? {
        try {
            if (!File(apkPath).exists()) {
                XLog.e("模块资源：模块 APK 不存在 $apkPath")
                return null
            }
            val am = AssetManager::class.java
                .getDeclaredConstructor()
                .apply { isAccessible = true }
                .newInstance()
            val addAssetPath = AssetManager::class.java
                .getDeclaredMethod("addAssetPath", String::class.java)
                .apply { isAccessible = true }
            val cookie = addAssetPath.invoke(am, apkPath) as? Int ?: 0
            if (cookie == 0) {
                XLog.e("模块资源：addAssetPath 返回 0（$apkPath）")
                return null
            }
            val dm = app.resources.displayMetrics
            val cfg = app.resources.configuration
            val res = Resources(am, dm, cfg)
            XLog.i("模块资源：addAssetPath 成功 path=$apkPath")
            return res
        } catch (t: Throwable) {
            XLog.e("模块资源：addAssetPath 失败（$apkPath）", t)
            return null
        }
    }
}
