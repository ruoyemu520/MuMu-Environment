# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# ============ LSPosed / LSPatch / NPatch 模块保命规则 ============
# 模块入口类由 assets/xposed_init 里写死的字符串查找，被混淆/裁剪就会「模块不生效」。
-keep class com.example.myno.clans.hook.** { *; }
# 实现 IXposedHookLoadPackage / IXposedHookZygoteInit 的类必须保留
-keep class * implements de.robv.android.xposed.IXposedHookLoadPackage { *; }
-keep class * implements de.robv.android.xposed.IXposedHookZygoteInit { *; }
# hook 回调里的匿名内部类也要留
-keepclassmembers class * extends de.robv.android.xposed.XC_MethodHook { *; }

# ---- 现代管线（Xposed API 101/102，io.github.libxposed）----
# 入口类由 META-INF/xposed/java_init.list 里的字符串查找
-keep class com.example.myno.clans.modern.** { *; }
# 必须继承 XposedModule：框架会 isAssignableFrom + 反射调用无参构造
-keep class * extends io.github.libxposed.api.XposedModule { *; }
-keep class * implements io.github.libxposed.api.XposedInterface$Hooker { *; }
# 现代入口那条路径上不允许出现 de.robv.*，但这不影响 R8 保持规则本身
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile