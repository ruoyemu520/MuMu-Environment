#!/usr/bin/env python3
"""纯 Python PNG 解码 + 画面分析（无 PIL / cv2 环境下的替代品）。

用法:
  python3 pngtool.py info    <png>
  python3 pngtool.py palette <png> [topN]
  python3 pngtool.py ascii   <png> [cols]
  python3 pngtool.py color   <png> [cols]
  python3 pngtool.py box     <png> [cols]     # 按色块分区
"""
import sys
import zlib
import struct
from collections import Counter


def decode_png(path):
    data = open(path, 'rb').read()
    assert data[:8] == b'\x89PNG\r\n\x1a\n', 'not a png'
    pos = 8
    idat = bytearray()
    w = h = bitdepth = colortype = None
    palette = None
    while pos < len(data):
        (ln,) = struct.unpack('>I', data[pos:pos + 4])
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b'IHDR':
            w, h, bitdepth, colortype, comp, filt, interlace = struct.unpack('>IIBBBBB', body)
            assert interlace == 0, 'interlaced png unsupported'
            assert bitdepth == 8, 'only 8-bit supported, got %d' % bitdepth
        elif typ == b'PLTE':
            palette = [tuple(body[i:i + 3]) for i in range(0, len(body), 3)]
        elif typ == b'IDAT':
            idat += body
        elif typ == b'IEND':
            break
    raw = zlib.decompress(bytes(idat))

    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[colortype]
    stride = w * channels
    out = bytearray(h * stride)
    prev = bytearray(stride)
    p = 0
    for y in range(h):
        ft = raw[p]
        p += 1
        line = bytearray(raw[p:p + stride])
        p += stride
        if ft == 1:
            for i in range(channels, stride):
                line[i] = (line[i] + line[i - channels]) & 0xFF
        elif ft == 2:
            for i in range(stride):
                line[i] = (line[i] + prev[i]) & 0xFF
        elif ft == 3:
            for i in range(stride):
                a = line[i - channels] if i >= channels else 0
                line[i] = (line[i] + ((a + prev[i]) >> 1)) & 0xFF
        elif ft == 4:
            for i in range(stride):
                a = line[i - channels] if i >= channels else 0
                b = prev[i]
                c = prev[i - channels] if i >= channels else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[i] = (line[i] + pr) & 0xFF
        out[y * stride:(y + 1) * stride] = line
        prev = line

    # 统一成 RGB
    rgb = bytearray(w * h * 3)
    if colortype == 6:
        for i in range(w * h):
            rgb[i * 3:i * 3 + 3] = out[i * 4:i * 4 + 3]
    elif colortype == 2:
        rgb[:] = out
    elif colortype == 0:
        for i in range(w * h):
            v = out[i]
            rgb[i * 3] = rgb[i * 3 + 1] = rgb[i * 3 + 2] = v
    elif colortype == 4:
        for i in range(w * h):
            v = out[i * 2]
            rgb[i * 3] = rgb[i * 3 + 1] = rgb[i * 3 + 2] = v
    elif colortype == 3:
        for i in range(w * h):
            r, g, b = palette[out[i]]
            rgb[i * 3:i * 3 + 3] = bytes((r, g, b))
    return w, h, rgb


def px(rgb, w, x, y):
    i = (y * w + x) * 3
    return rgb[i], rgb[i + 1], rgb[i + 2]


def downsample(rgb, w, h, cols):
    rows = max(1, int(cols * h / w / 2.1))
    cw, ch = w / cols, h / rows
    grid = []
    for ry in range(rows):
        row = []
        for rx in range(cols):
            x0, x1 = int(rx * cw), max(int(rx * cw) + 1, int((rx + 1) * cw))
            y0, y1 = int(ry * ch), max(int(ry * ch) + 1, int((ry + 1) * ch))
            sr = sg = sb = n = 0
            for y in range(y0, min(y1, h), max(1, (y1 - y0) // 6)):
                for x in range(x0, min(x1, w), max(1, (x1 - x0) // 6)):
                    r, g, b = px(rgb, w, x, y)
                    sr += r
                    sg += g
                    sb += b
                    n += 1
            row.append((sr // n, sg // n, sb // n))
        grid.append(row)
    return grid


def hexc(c):
    return '#%02X%02X%02X' % c


def cmd_info(path):
    w, h, rgb = decode_png(path)
    print('尺寸: %dx%d' % (w, h))
    cnt = Counter()
    for y in range(0, h, 3):
        for x in range(0, w, 3):
            cnt[px(rgb, w, x, y)] += 1
    print('不同颜色数(采样): %d' % len(cnt))
    tot = sum(cnt.values())
    print('Top 12 颜色:')
    for c, n in cnt.most_common(12):
        print('  %s  %5.2f%%  rgb%s' % (hexc(c), 100.0 * n / tot, c))


def cmd_palette(path, topn=20):
    w, h, rgb = decode_png(path)
    cnt = Counter()
    for y in range(h):
        for x in range(0, w, 2):
            cnt[px(rgb, w, x, y)] += 1
    tot = sum(cnt.values())
    for c, n in cnt.most_common(topn):
        print('%s  %5.2f%%  rgb(%d,%d,%d)' % (hexc(c), 100.0 * n / tot, c[0], c[1], c[2]))


RAMP = ' .:-=+*#%@'


def cmd_ascii(path, cols=64):
    w, h, rgb = decode_png(path)
    grid = downsample(rgb, w, h, cols)
    print('原图 %dx%d -> %dx%d' % (w, h, cols, len(grid)))
    for row in grid:
        line = ''
        for (r, g, b) in row:
            lum = (r * 299 + g * 587 + b * 114) // 1000
            line += RAMP[min(len(RAMP) - 1, lum * len(RAMP) // 256)]
        print(line)


def sat_ramp(r, g, b):
    mx, mn = max(r, g, b), min(r, g, b)
    if mx - mn < 26:
        return RAMP[min(len(RAMP) - 1, mx * len(RAMP) // 256)]
    if r >= g and r >= b:
        return 'R' if g > b + 30 else 'M' if b > g + 30 else 'r'
    if g >= r and g >= b:
        return 'Y' if r > b + 30 else 'G' if b > r + 30 else 'g'
    return 'C' if g > r + 30 else 'B' if r > g + 30 else 'b'


def cmd_color(path, cols=64):
    w, h, rgb = decode_png(path)
    grid = downsample(rgb, w, h, cols)
    print('原图 %dx%d -> %dx%d  (R红 M品红 r暗红 Y黄 G绿 g暗绿 C青 B蓝 b暗蓝 .黑 #灰 @白)' % (w, h, cols, len(grid)))
    for row in grid:
        print(''.join(sat_ramp(*c) for c in row))


def cmd_box(path, cols=48):
    w, h, rgb = decode_png(path)
    grid = downsample(rgb, w, h, cols)
    print('每格标注该格平均色的 hex（前 6 字符）')
    for ry, row in enumerate(grid):
        print('%3d ' % (ry * h // len(grid)) + ' '.join(hexc(c)[1:] for c in row))


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'info'
    p = sys.argv[2]
    a = int(sys.argv[3]) if len(sys.argv) > 3 else None
    if cmd == 'info':
        cmd_info(p)
    elif cmd == 'palette':
        cmd_palette(p, a or 20)
    elif cmd == 'ascii':
        cmd_ascii(p, a or 64)
    elif cmd == 'color':
        cmd_color(p, a or 64)
    elif cmd == 'box':
        cmd_box(p, a or 48)
    else:
        print(__doc__)
