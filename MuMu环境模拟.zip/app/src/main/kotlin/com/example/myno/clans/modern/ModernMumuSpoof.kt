package com.example.myno.clans.modern

import com.example.myno.clans.hook.XLog
import io.github.libxposed.api.XposedInterface
import java.lang.reflect.Executable
import java.util.Collections
import java.util.HashMap

/**
 * ============ MuMu 模拟器环境模拟（现代管线 / Xposed API 101 / 102）============
 *
 * 与 [com.example.myno.clans.hook.MumuSpoof] **行为完全一致**，只是换了 hook 的方式：
 *   · legacy：XposedHelpers.findAndHookMethod + XC_MethodHook.beforeHookedMethod + setResult
 *   · modern：module.hook(Executable).intercept(Hooker)，**直接 return 结果**来跳过原方法
 *
 * 伪装点的来龙去脉、每一条为什么这么钉，全部写在 legacy 版的类注释里
 * （那段注释把网易登录 SDK 的 MuMu 判定链从 `ak.c` 一路走到 `aj.o`），这里不重复。
 * 一句话版本：ro.build.id / JSON 是原模块的两条；
 * 真正决定「登录页要不要给扫码入口」的是 `mpay.f.b.l` 解析出来的
 * `support_qrcode_login` / `qrcode_login_allow_mobile` 两个配置键。
 *
 * ⚠️ 这个文件里**不能出现任何 de.robv.android.xposed.\* 的静态引用**。
 *    targetApiVersion >= 102 时，框架的模块 ClassLoader（VectorModuleClassLoader）
 *    会对这些类名直接抛 ClassNotFoundException，类校验一触发就把入口带崩。
 *
 *    所以这些字面量（BUILD_ID_KEY / BUILD_ID_VALUE / FAKE_TRUE / JSON_KEYS /
 *    QR_FLAG_KEYS / QR_DISABLE_REASON_KEY / GATES）在这里**故意重新写了一遍**，
 *    而不是 import [com.example.myno.clans.hook.MumuSpoof] 去读它的 const val ——
 *    虽然 Kotlin 的 const val 会编译期内联、理论上不会留下类引用，
 *    但「理论上」不值得赌：只要有一次没内联成功，JVM 就会去加载 MumuSpoof，
 *    而那个类的签名里带着 XC_MethodHook，整条现代管线当场崩。
 *    字面量重复是可以接受的成本 —— 没有单测兜底，**改一边记得改另一边**。
 *
 * ⚠️ **无条件生效，没有开关**（按用户要求：默认开 + 不可关闭）。
 *    这里同样**不读任何偏好值**，所以连 `Config` / `Feature` 都不 import。
 *    面板「杂项」页的「MuMu 环境」只是一行占位展示，没有关闭入口。
 */
internal object ModernMumuSpoof {

    /** 与 [com.example.myno.clans.hook.MumuSpoof.BUILD_ID_KEY] 保持一致 */
    private const val BUILD_ID_KEY = "ro.build.id"

    /** 与 [com.example.myno.clans.hook.MumuSpoof.BUILD_ID_VALUE] 保持一致 */
    private const val BUILD_ID_VALUE = "V417IR"

    /** 与 [com.example.myno.clans.hook.MumuSpoof.FAKE_TRUE] 保持一致 */
    private const val FAKE_TRUE = "1"

    /** 与原模块一致的两个 JSON key */
    private val JSON_KEYS = setOf("isMuMu", "isEmulator")

    /** 与 [com.example.myno.clans.hook.MumuSpoof] 里的 QR_FLAG_KEYS 保持一致 */
    private val QR_FLAG_KEYS = setOf("support_qrcode_login", "qrcode_login_allow_mobile")

    /** 与 legacy 版保持一致 */
    private const val QR_DISABLE_REASON_KEY = "disable_qrcode_login_reason"

    /** 配置解析器：`com.netease.mpay.f.b.l`，见 legacy 版注释第 4 组 */
    private const val CONFIG_PARSER = "com.netease.mpay.f.b.l"

    /** 「无参静态方法 → 固定返回值」，与 legacy 版的 Gate 一一对应 */
    private class Gate(
        val clazz: String,
        val method: String,
        val result: Any,
        val note: String
    )

    private val GATES = listOf(
        // --- 设备判定（ai.a() 是所有 MuMu 分支的总闸门）---
        Gate("com.netease.mpay.widget.ai", "a", true, "设备判定总闸门：这台机器是 MuMu"),
        Gate("com.netease.mpay.widget.ai", "d", true, "机型名匹配（V417IR / W528JS）"),
        Gate("com.netease.mpay.widget.ai", "c", BUILD_ID_VALUE, "直接读 ro.build.id"),
        Gate("com.netease.mpay.widget.ai", "b", "MuMu", "把设备名报成 MuMu"),

        // --- 登录页扫码入口 ---
        Gate("com.netease.mpay.login.a", "g", true, "登录页保留扫码登录入口"),
        Gate("com.netease.mpay.login.a", "h", true, "登录页扫码能力（服务端标记）"),
        Gate("com.netease.mpay.login.a", "d", true, "登录页首选平台 = 扫码（决定登录页变体）"),
        // view/a/a/a;->u() 按 c.b → c.c → c.a 的顺序选登录页变体，
        // c.a == login.a.d() == LOGIN_QRCODE_LOGIN，所以把 e()/f() 压成 false
        // 是为了保证扫码页赢过抖音云登录页。详见 legacy 版注释。
        Gate("com.netease.mpay.login.a", "e", false, "让出优先级：抖音云登录页"),
        Gate("com.netease.mpay.login.a", "f", false, "让出优先级：抖音云登录页"),

        // --- 强制 MuMu 平台（等价 SDK 的 FORCE_MUMU_PLATFORM）---
        Gate("com.netease.mpay.g\$a", "a", true, "强制 MuMu 平台判定生效"),
        Gate("com.netease.mpay.g\$a", "b", 5, "强制 MuMu 平台编号 5 = PC"),

        // --- 第 5 组到此为止 ---
        //
        // ⚠️ 与 legacy 版完全一致：**故意不挂**
        //    com.netease.ntunisdk.SdkNetease.isConfigMuMuDevice()。
        //    SdkNetease → NeteaseBase → ChannelAAS → SdkBase 这条链在 classes.dex 里
        //    都有 class_def，但 SdkBase 实现了一个插件才有的接口
        //        Lcom/netease/ntunisdk/base/GamerInterface;
        //    六个 dex 里都没有它的 class_def（ngplugin 运行时下载），
        //    ART 加载类时解析整条「父类 + 接口」链，于是
        //        Class.forName("com.netease.ntunisdk.SdkNetease", false, cl)
        //    必抛 NoClassDefFoundError（报的是父类 NeteaseBase 的名字，真正缺的是上面那个接口）。
        //
        //    异常虽然被 hookMethod 的 try/catch 吞了，但当时那行日志是把 Throwable
        //    一起交给日志系统的，而 NPatch 会**记录模块产生的异常**，再在
        //    LSPAppComponentFactoryStub.<clinit> / bootstrapOrThrow 里原样重抛 →
        //    ExceptionInInitializerError → FATAL EXCEPTION: main → 游戏起不来、
        //    悬浮窗也出不来（它是 onPackageReady 里同一段后面的代码）。
        //    实测 2026-10-09：GATES 12 条里 11 条「已 hook」成功、只有这一条「失败」，
        //    模块其它部分全装完，进程依然被 NPatch 带走。
        //
        //    结论两条，缺一不可（与 legacy 版一致）：
        //      a) 会抛异常的 hook 一个都不能留 —— 加 Gate 前先跑
        //         `python3 tools/check_gate_classes.py --from-source <本文件>`；
        //      b) 异常只记文字、**不交给日志系统**（见 [failSkip] 与 XLog）。
        //    详细说明见 legacy 版 hook/MumuSpoof.kt 与 README_LSPosed.md §12.9。
    )

    @Volatile
    private var installed = false

    fun install(module: XposedInterface, cl: ClassLoader) {
        if (installed) return
        installed = true

        // ---- 第 1 组：系统属性 ----
        // get(String)
        hookMethod(
            module, cl, "android.os.SystemProperties", "get",
            arrayOf(String::class.java)
        ) { args -> propertyValue(args) }
        // get(String, String) —— 原模块挂的就是这个，也是 ak.c 反射调用的那个
        hookMethod(
            module, cl, "android.os.SystemProperties", "get",
            arrayOf(String::class.java, String::class.java)
        ) { args -> propertyValue(args) }

        // ---- 第 2 组：JSON ----
        // optString(String)
        hookMethod(module, cl, "org.json.JSONObject", "optString", arrayOf(String::class.java)) { args ->
            jsonValue(args)
        }
        // optString(String, String) —— 原模块挂的就是这个
        hookMethod(
            module, cl, "org.json.JSONObject", "optString",
            arrayOf(String::class.java, String::class.java)
        ) { args -> jsonValue(args) }

        // ---- 第 3~5 组：Java 层闸门 ----
        for (gate in GATES) {
            hookMethod(module, cl, gate.clazz, gate.method, emptyArray()) {
                logHit("${gate.clazz}.${gate.method}", gate.result.toString())
                gate.result
            }
        }

        // ---- 第 4 组补充：扫码开关是「配置键解析」出来的 ----
        // c(HashMap, String)Z
        hookMethod(
            module, cl, CONFIG_PARSER, "c",
            arrayOf(HashMap::class.java, String::class.java)
        ) { args ->
            val key = args.getOrNull(1) as? String
            if (key != null && key in QR_FLAG_KEYS) {
                logHit("$CONFIG_PARSER.c:$key", "true")
                true
            } else {
                NOT_HANDLED
            }
        }
        // a(HashMap, String)String
        hookMethod(
            module, cl, CONFIG_PARSER, "a",
            arrayOf(HashMap::class.java, String::class.java)
        ) { args ->
            val key = args.getOrNull(1) as? String
            if (key == QR_DISABLE_REASON_KEY) {
                logHit("$CONFIG_PARSER.a:$key", "（清空）")
                ""
            } else {
                NOT_HANDLED
            }
        }
    }

    /** `ro.build.id` → V417IR，其它属性一律放行 */
    private fun propertyValue(args: List<Any?>): Any? {
        val key = args.getOrNull(0) as? String ?: return NOT_HANDLED
        if (key != BUILD_ID_KEY) return NOT_HANDLED
        logHit(key, BUILD_ID_VALUE)
        return BUILD_ID_VALUE
    }

    /** `isMuMu` / `isEmulator` → "1"，其它 key 一律放行 */
    private fun jsonValue(args: List<Any?>): Any? {
        val key = args.getOrNull(0) as? String ?: return NOT_HANDLED
        if (key !in JSON_KEYS) return NOT_HANDLED
        logHit(key, FAKE_TRUE)
        return FAKE_TRUE
    }

    /**
     * 装一个 hook。命中（block 返回值不是 [NOT_HANDLED]）就**跳过原方法**，
     * 否则照常 `chain.proceed()`。
     *
     * `Class.forName(className, false, cl)` 的 `false` = 不初始化类：
     * 这些 SDK 类的静态初始化块可能会回调一堆还没准备好的东西，
     * hook 阶段触发它没好处。传游戏自己的 ClassLoader，否则找不到这些类。
     */
    private fun hookMethod(
        module: XposedInterface,
        cl: ClassLoader,
        className: String,
        methodName: String,
        paramTypes: Array<Class<*>>,
        block: (List<Any?>) -> Any?
    ) {
        val label = "$className.$methodName(${paramTypes.joinToString { it.simpleName }})"
        try {
            val cls = Class.forName(className, false, cl)
            val m: Executable = if (paramTypes.isEmpty()) {
                cls.getDeclaredMethod(methodName)
            } else {
                cls.getDeclaredMethod(methodName, *paramTypes)
            }
            module.hook(m).intercept(ModernBeforeHooker(block))
            XLog.i("Modern: MumuSpoof 已 hook $label")
        } catch (t: Throwable) {
            failSkip(label, t)
        }
    }

    /**
     * hook 装不上时的统一出口。
     *
     * ⚠️ **故意不把 Throwable 交给 XLog.e / Log.e**，只把 `toString()` 拼进文字。
     *    原因见 [GATES] 末尾：NPatch 会记录模块产生的异常并在 bootstrap 阶段重抛，
     *    「我们 catch 住了」在 NPatch 下**不等于没事**，所以连「把异常递给日志系统」
     *    这一步都不做。保留 `toString()` 已经够看清是什么异常、缺哪个类。
     *
     * 注意：这只是**最后一道保险**。真正保证不抛异常的是
     * `tools/check_gate_classes.py`（加 Gate 前先跑它验「父类 + 接口」链）。
     */
    private fun failSkip(label: String, t: Throwable) {
        XLog.e("Modern: MumuSpoof hook $label 失败（跳过）：$t")
    }

    // ------------------------------------------------------------------
    // 命中打点
    // ------------------------------------------------------------------

    /**
     * 已经打过日志的 key，**每个 key 只打一次**，避免热方法刷屏
     * （`JSONObject.optString` 一秒可能被调几千次）。
     *
     * 与 legacy 版完全一致：`Collections.synchronizedSet` 保证跨线程安全，
     * `Set.add` 的返回值天然就是「我是不是第一个」。
     * 「hook 装上了」不等于「伪装被读到了」，这条日志是唯一能区分两者的东西。
     */
    private val hitLogged: MutableSet<String> = Collections.synchronizedSet(mutableSetOf<String>())

    private fun logHit(key: String, value: String) {
        if (hitLogged.add(key)) {
            XLog.i("Modern: MumuSpoof 命中 $key → $value（伪装被游戏读到了）")
        }
    }
}

/** [ModernBeforeHooker] 用这个哨兵表示「我不接管，照常走原方法」 */
private val NOT_HANDLED = Any()

/**
 * 现代「前置」Hooker：先跑我们的逻辑，命中就**直接 return** 跳过原方法，
 * 否则照常 `chain.proceed()` 并把它的结果返回去。
 *
 * ⚠️ 这里有个和 legacy 完全不同的坑，值得记下来：
 *    legacy 跳过原方法是 `param.setResult(v)`；
 *    modern 的 `Chain` **没有** setResult 这种东西 —— `proceedWith(...)` 名字虽然像，
 *    但签名是 `proceedWith(Object thisObject)` / `proceedWith(Object, Object[])`，
 *    意思是「换个 this 指针 / 换一套参数继续往下走」，**不是**「设定返回值」。
 *    真正的机制在 Hooker 的返回值上：
 *      "If the hooker does not want to change the result, it should call
 *       chain.proceed() and return its result."
 *    —— 也就是说**不调 proceed() 时，intercept() 返回什么，方法结果就是什么**。
 *    只看方法名很容易写成 proceedWith(v)（那就是把 v 当成 this 指针传下去了）。
 *
 * API 102 起已经不需要 @XposedHooker 注解（那个注解压根不在 io.github.libxposed:api:102 里）。
 */
internal class ModernBeforeHooker(
    private val block: (List<Any?>) -> Any?
) : XposedInterface.Hooker {

    override fun intercept(chain: XposedInterface.Chain): Any? {
        val r: Any? = try {
            block(chain.args)
        } catch (t: Throwable) {
            // 不带 Throwable，理由同 failSkip：别给框架任何 printStackTrace 的机会。
            XLog.e("Modern: MumuSpoof 回调抛异常（已吞掉，照常走原方法）：$t")
            NOT_HANDLED
        }
        // 不接管 → 老老实实走原方法；接管 → 直接返回，原方法不会被调用
        return if (r === NOT_HANDLED) chain.proceed() else r
    }
}
