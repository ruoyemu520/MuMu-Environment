package com.example.myno.clans.overlay

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.Resources
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import com.example.myno.clans.R
import com.example.myno.clans.hook.Config
import com.example.myno.clans.hook.Feature

class OverlayController private constructor(
    private val app: Context,
    private val moduleRes: Resources?,
    private val decor: ViewGroup?
) {

    companion object {
        private val SCHEMES = listOf(Config.DEFAULT_SCHEME, "方案 A", "方案 B")

        /** 背景不再绑定内置图片；可选纯色、网络图片或本地图片。 */
        val BG_OPTIONS = listOf("深色", "网页背景")

        private const val BG_CUSTOM = "自定义图片"
        private const val BG_WEB = "网页背景"
        private const val WEB_IMAGE_FILE = "clans_bg_web.jpg"
        private val BG_GRADIENTS = mapOf(
            "深色" to intArrayOf(Color.parseColor("#1B1626"), Color.parseColor("#0E0B14")),
            "粉色渐变" to intArrayOf(Color.parseColor("#5A2A4A"), Color.parseColor("#2A1424")),
            "蓝紫渐变" to intArrayOf(Color.parseColor("#2A2F5A"), Color.parseColor("#15102A"))
        )

        /** 透明度下限：再低面板就看不见了，容易以为程序挂了 */
        private const val MIN_OPACITY = 0.2f

        /** WindowManager 悬浮窗模式：需要目标应用持有悬浮窗权限 */
        fun forWindow(app: Context, moduleRes: Resources?): OverlayController {
            val c = OverlayController(app.applicationContext, moduleRes, null)
            c.attach()
            return c
        }

        /** 塞进 Activity 的 decorView：不需要悬浮窗权限；decorView 不是 ViewGroup 时返回 null */
        fun forDecor(activity: Activity, moduleRes: Resources?): OverlayController? {
            val d = activity.window?.decorView as? ViewGroup ?: return null
            val c = OverlayController(activity, moduleRes, d)
            c.attach()
            return c
        }
    }

    private val wm: WindowManager? =
        if (decor == null) app.getSystemService(Context.WINDOW_SERVICE) as? WindowManager else null

    private var ballLp: WindowManager.LayoutParams? = null
    private var panelLp: WindowManager.LayoutParams? = null

    private var floatingView: View? = null
    private var panelView: View? = null
    private var panelVisible = false

    private var selectedTab = 0
    private var isAnimatingTab = false

    private var contentFlipper: FrameLayout? = null
    private var bgHost: FrameLayout? = null
    private var navContainer: LinearLayout? = null
    private var navCapsule: View? = null

    private val navLines = mutableListOf<View>()
    private val navDots = mutableListOf<View>()
    private val navTexts = mutableListOf<TextView>()

    private var navIsVertical = false
    private var navItemSize = 0

    private var breathAnimator: ObjectAnimator? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val activeColor = Color.parseColor("#FF82BE")
    private val inactiveColor = Color.parseColor("#DDC8DC")

    val isAttached: Boolean get() = floatingView != null

    /**
     * 用户点了面板里的「关闭悬浮窗」时回调。
     * Installer 用它记住「本次别再自动挂载」—— 否则下一次 onResume
     * （游戏里随便切个界面就会触发）悬浮球马上又回来了，关闭按钮等于没用。
     */
    var onUserClosed: (() -> Unit)? = null

    private fun attach() {
        createFloatingBall()
    }

    private fun dp(v: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v,
            app.resources.displayMetrics
        ).toInt()
    }

    private fun moduleDrawable(id: Int): Drawable? =
        try {
            moduleRes?.getDrawable(id, null)
        } catch (t: Throwable) {
            null
        }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun attachBall(ball: View, size: Int, x: Int, y: Int) {
        val d = decor
        if (d != null) {
            d.addView(ball, FrameLayout.LayoutParams(size, size).apply {
                gravity = Gravity.TOP or Gravity.START
                leftMargin = x
                topMargin = y
            })
        } else {
            val lp = WindowManager.LayoutParams(
                size, size, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                this.x = x
                this.y = y
            }
            ballLp = lp
            wm?.addView(ball, lp)
        }
    }

    private fun moveBall(x: Int, y: Int) {
        val ball = floatingView ?: return
        // 夹在屏幕内：原版没做限制，能把悬浮球拖出屏幕再也找不回来
        val dm = app.resources.displayMetrics
        val maxX = (dm.widthPixels - ball.width).coerceAtLeast(0)
        val maxY = (dm.heightPixels - ball.height).coerceAtLeast(0)
        val cx = x.coerceIn(0, maxX)
        val cy = y.coerceIn(0, maxY)

        val d = decor
        if (d != null) {
            val lp = ball.layoutParams as? FrameLayout.LayoutParams ?: return
            lp.leftMargin = cx
            lp.topMargin = cy
            ball.layoutParams = lp
        } else {
            val lp = ballLp ?: return
            lp.x = cx
            lp.y = cy
            wm?.updateViewLayout(ball, lp)
        }
    }

    private fun attachPanel(v: View) {
        val d = decor
        if (d != null) {
            d.addView(
                v,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        } else {
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            panelLp = lp
            wm?.addView(v, lp)
        }
    }

    private fun detach(v: View) {
        try {
            if (decor != null) decor.removeView(v) else wm?.removeView(v)
        } catch (t: Throwable) {
            // 已移除或不属于本宿主，忽略
        }
    }

    private fun createFloatingBall() {
        val size = dp(56f)

        val ball = ImageView(app).apply {
            val d = moduleDrawable(R.drawable.xuanfu)
            if (d != null) {
                setImageDrawable(d)
            } else {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#FF82BE"))
                    setStroke(dp(2f), Color.WHITE)
                }
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(
                    view: View,
                    outline: Outline
                ) {
                    val radius = size / 4f
                    outline.setRoundRect(0, 0, size, size, radius)
                }
            }
        }

        val startX = dp(16f)
        val startY = dp(80f)

        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        var isDragging = false

        ball.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val lp = floatingView?.layoutParams
                    if (lp is FrameLayout.LayoutParams && decor != null) {
                        initialX = lp.leftMargin
                        initialY = lp.topMargin
                    } else {
                        initialX = ballLp?.x ?: 0
                        initialY = ballLp?.y ?: 0
                    }
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isDragging = false
                    v.animate()
                        .scaleX(0.92f)
                        .scaleY(0.92f)
                        .setDuration(120)
                        .start()
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchStartX
                    val dy = event.rawY - touchStartY

                    if (!isDragging &&
                        (Math.abs(dx) > 10 ||
                                Math.abs(dy) > 10)
                    ) {
                        isDragging = true
                        v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(120)
                            .start()
                    }

                    if (isDragging) {
                        moveBall(
                            initialX + dx.toInt(),
                            initialY + dy.toInt()
                        )
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    v.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(300)
                        .setInterpolator(
                            OvershootInterpolator(2f)
                        )
                        .start()

                    if (!isDragging) {
                        togglePanel()
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    v.animate()
                        .scaleX(1f)
                        .scaleY(1f)
                        .setDuration(200)
                        .start()
                    true
                }

                else -> false
            }
        }

        floatingView = ball
        attachBall(ball, size, startX, startY)
        startBreathAnimation(ball)
    }

    private fun startBreathAnimation(v: View) {
        breathAnimator = ObjectAnimator.ofPropertyValuesHolder(
            v,
            PropertyValuesHolder.ofFloat("scaleX", 1.0f, 1.05f),
            PropertyValuesHolder.ofFloat("scaleY", 1.0f, 1.05f)
        ).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun togglePanel() {
        if (panelVisible) hidePanel() else showPanel()
    }

    private fun showPanel() {
        if (panelView != null) return

        selectedTab = 0

        // 横屏用左导航 + 右内容的横向布局；竖屏仍用原来的顶部导航布局。
        val dm = app.resources.displayMetrics
        panelView = if (dm.widthPixels > dm.heightPixels) buildLandscapePanel()
        else buildPortraitPanel()

        attachPanel(panelView!!)
        panelVisible = true

        // 动画终点是「配置里存的不透明度」，不是写死的 1f，
        // 否则每次打开面板都会把用户调好的透明度顶回不透明。
        val targetAlpha = Config.opacity(app).coerceIn(MIN_OPACITY, 1f)

        panelView?.apply {
            alpha = 0f
            scaleX = 0.7f
            scaleY = 0.7f
            animate()
                .alpha(targetAlpha)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(450)
                .setInterpolator(
                    OvershootInterpolator(1.5f)
                )
                .start()
        }
    }

    private fun hidePanel() {
        val pv = panelView
        if (pv == null) {
            panelVisible = false
            return
        }
        pv.animate().cancel()
        detach(pv)
        panelView = null
        panelVisible = false
        contentFlipper = null
        bgHost = null
        navContainer = null
        navCapsule = null
        navLines.clear()
        navDots.clear()
        navTexts.clear()
    }

    fun destroy() {
        breathAnimator?.cancel()
        hidePanel()
        floatingView?.let {
            detach(it)
            floatingView = null
        }
    }

    private fun buildPortraitPanel(): View {
        val root = FrameLayout(app).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }
        root.setOnClickListener { hidePanel() }

        val panelW =
            (app.resources.displayMetrics.widthPixels * 0.85f).toInt()
        val panelH =
            (app.resources.displayMetrics.heightPixels * 0.60f).toInt()

        val panel = FrameLayout(app).apply {
            layoutParams = FrameLayout.LayoutParams(
                panelW,
                panelH
            ).apply {
                gravity = Gravity.CENTER
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(
                    view: View,
                    outline: Outline
                ) {
                    outline.setRoundRect(
                        0,
                        0,
                        view.width,
                        view.height,
                        dp(14f).toFloat()
                    )
                }
            }
            setOnClickListener { }
        }

        val bg = FrameLayout(app).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        bgHost = bg
        panel.addView(bg)
        applyBackground()

        panel.addView(View(app).apply {
            setBackgroundColor(
                Color.parseColor("#99000000")
            )
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        })

        panel.addView(View(app).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1.5f), activeColor)
                cornerRadius = dp(14f).toFloat()
            }
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        })

        val column = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            elevation = dp(4f).toFloat()
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        panel.addView(column)

        column.addView(buildTitleBar())
        column.addView(makeDivider())

        navIsVertical = false
        navItemSize = 0

        val topNavWrapper = FrameLayout(app).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(48f)
            )
        }

        val topNav = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(
                Color.parseColor("#6615101A")
            )
            setPadding(dp(8f), dp(6f), dp(8f), dp(6f))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        navContainer = topNav
        buildNavItems(topNav)
        topNavWrapper.addView(topNav)

        // 胶囊单独放在 topNavWrapper
        val capsule = View(app).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(10f).toFloat()
                setColor(Color.parseColor("#33FF82BE"))
                setStroke(dp(1f), activeColor)
            }
            visibility = View.INVISIBLE
            layoutParams = FrameLayout.LayoutParams(
                dp(60f),
                dp(32f)
            ).apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                leftMargin = dp(4f)
            }
        }
        navCapsule = capsule
        topNavWrapper.addView(capsule)

        column.addView(topNavWrapper)
        column.addView(makeDivider())

        val contentBody = FrameLayout(app).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            clipToPadding = false
            clipChildren = false
        }
        contentFlipper = contentBody
        contentBody.addView(buildContentArea())
        column.addView(contentBody)

        // 底栏独立锚定在面板最底部，不参与 column 的内容高度计算。
        // 这样不会覆盖设置页，也不会因为内容高度变化跑到内容顶部。
        val bottomArea = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(45f)
            ).apply {
                gravity = Gravity.BOTTOM
            }
        }
        bottomArea.addView(makeDivider())
        bottomArea.addView(buildBottomBar())
        panel.addView(bottomArea)

        root.addView(panel)

        panel.postDelayed({
            moveCapsule(selectedTab)
        }, 200L)

        return root
    }

    /**
     * 横屏面板：顶部标题栏，下面左边是竖向导航、右边是内容区，底部状态栏。
     * 面板占屏幕约 72% 宽 × 84% 高，点面板外的空白处关闭。
     */
    private fun buildLandscapePanel(): View {
        val dm = app.resources.displayMetrics
        val root = FrameLayout(app).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }
        root.setOnClickListener { hidePanel() }

        val panelW = (dm.widthPixels * 0.72f).toInt()
        val panelH = (dm.heightPixels * 0.84f).toInt()

        val panel = FrameLayout(app).apply {
            layoutParams = FrameLayout.LayoutParams(panelW, panelH).apply {
                gravity = Gravity.CENTER
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(
                        0, 0, view.width, view.height, dp(14f).toFloat()
                    )
                }
            }
            setOnClickListener { }
        }

        val bg = FrameLayout(app).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        bgHost = bg
        panel.addView(bg)
        applyBackground()
        panel.addView(View(app).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        })
        panel.addView(View(app).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1.5f), activeColor)
                cornerRadius = dp(14f).toFloat()
            }
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        })

        // 底栏高 45dp，列底部留出同样的空间，内容不会被盖住
        val column = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            elevation = dp(4f).toFloat()
            setPadding(0, 0, 0, dp(45f))
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        panel.addView(column)

        column.addView(buildTitleBar())
        column.addView(makeDivider())

        navIsVertical = true
        navItemSize = 0

        val body = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0
            ).apply { weight = 1f }
        }

        // 左侧竖向导航
        val sideNav = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#6615101A"))
            setPadding(0, dp(8f), 0, dp(8f))
            layoutParams = LinearLayout.LayoutParams(
                dp(124f),
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }
        navContainer = sideNav
        buildNavItems(sideNav)
        body.addView(sideNav)

        body.addView(View(app).apply {
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(
                dp(1f),
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        })

        // 右侧内容
        val contentBody = FrameLayout(app).apply {
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT
            ).apply { weight = 1f }
            clipToPadding = false
            clipChildren = false
        }
        contentFlipper = contentBody
        contentBody.addView(buildContentArea())
        body.addView(contentBody)

        column.addView(body)

        val bottomArea = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(45f)
            ).apply { gravity = Gravity.BOTTOM }
        }
        bottomArea.addView(makeDivider())
        bottomArea.addView(buildBottomBar())
        panel.addView(bottomArea)

        root.addView(panel)
        return root
    }

    /** 自定义背景图所在目录：游戏自己的外部专属目录，不需要任何存储权限 */
    private fun customBgDir(): File? =
        try { app.getExternalFilesDir(null) } catch (t: Throwable) { null }

    private fun loadCustomBg(): android.graphics.Bitmap? {
        val dirs = listOfNotNull(customBgDir(), app.filesDir)
        for (d in dirs) {
            for (name in listOf("clans_bg.png", "clans_bg.jpg", "clans_bg.jpeg")) {
                val f = File(d, name)
                if (!f.isFile) continue
                try {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(f.absolutePath, bounds)
                    var sample = 1
                    // 限制在约 1280px 内，避免大图撑爆内存
                    while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) {
                        sample *= 2
                    }
                    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                    val bmp = BitmapFactory.decodeFile(f.absolutePath, opts)
                    if (bmp != null) return bmp
                } catch (t: Throwable) {
                    // 读失败就试下一个，最后回退默认图
                }
            }
        }
        return null
    }

    private fun webBgFile(): File = File(app.filesDir, WEB_IMAGE_FILE)

    private fun loadWebBg(): android.graphics.Bitmap? {
        val file = webBgFile()
        if (!file.isFile) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Throwable) { null }
    }

    private fun toast(message: String) {
        mainHandler.post { Toast.makeText(app, message, Toast.LENGTH_SHORT).show() }
    }

    /** 参考镜花水月的壁纸接口：获取图片 URL 后下载并缓存到当前宿主私有目录。 */
    private fun fetchRandomWebBackground() {
        toast("正在获取随机网页背景…")
        Thread {
            try {
                val endpoint = if (app.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) "pc.php" else "pe.php"
                val api = URL("https://api.yppp.net/$endpoint?return=json&t=${System.currentTimeMillis()}")
                val connection = (api.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "Clans-Background/1.0")
                }
                val jsonText = try { connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText().take(100_000) } } finally { connection.disconnect() }
                val json = JSONObject(jsonText)
                if (json.optString("code") != "200") throw IllegalStateException("壁纸接口返回异常")
                val imageUrl = json.optString("acgurl")
                downloadAndSaveWebBg(imageUrl)
            } catch (t: Throwable) {
                toast("获取背景失败：${t.message ?: "网络或接口异常"}")
            }
        }.start()
    }

    private fun fetchWebBackground(imageUrl: String) {
        toast("正在加载图片网址…")
        Thread {
            try { downloadAndSaveWebBg(imageUrl) }
            catch (t: Throwable) { toast("图片加载失败：${t.message ?: "请检查网址"}") }
        }.start()
    }

    private fun downloadAndSaveWebBg(rawUrl: String) {
        val parsed = URL(rawUrl)
        require(parsed.protocol == "https" && parsed.userInfo == null) { "只允许 HTTPS 图片网址" }
        val connection = (parsed.openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 10000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Clans-Background/1.0")
        }
        val bytes = try {
            require(connection.responseCode in 200..299) { "图片服务器返回 ${connection.responseCode}" }
            require(connection.contentLengthLong <= 16L * 1024 * 1024 || connection.contentLengthLong < 0) { "图片超过 16 MB" }
            connection.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    total += n
                    require(total <= 16 * 1024 * 1024) { "图片超过 16 MB" }
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
        } finally { connection.disconnect() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "链接返回的不是可识别图片" }
        var sample = 1
        while (bounds.outWidth / sample > 1280 || bounds.outHeight / sample > 1280) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IllegalStateException("图片解码失败")
        val file = webBgFile()
        file.parentFile?.mkdirs()
        file.outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 86, it) }
        bitmap.recycle()
        Config.setBackground(app, BG_WEB)
        mainHandler.post {
            applyBackground()
            toast("网页背景已应用并缓存")
            refreshBackgroundSelection()
        }
    }

    private fun showImageUrlDialog() {
        val input = EditText(app).apply {
            hint = "https://example.com/image.jpg"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(inactiveColor)
            setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
        }
        try {
            AlertDialog.Builder(app)
                .setTitle("输入图片网址")
                .setMessage("填写图片文件的 HTTPS 直链，不是普通网页地址。")
                .setView(input)
                .setNegativeButton("取消", null)
                .setPositiveButton("应用") { _, _ ->
                    val value = input.text.toString().trim()
                    if (value.isBlank()) toast("请先输入图片网址") else fetchWebBackground(value)
                }
                .show()
        } catch (_: Throwable) {
            toast("当前悬浮窗环境无法打开输入框，请在游戏内面板使用或稍后重试")
        }
    }

    private fun refreshBackgroundSelection() {
        applyBackground()
        // 重新创建设置页，让下拉项同步显示“网页背景”。
        switchContent(selectedTab, selectedTab)
    }

    /** 按当前配置重画面板背景层；切换背景时直接调用，立即生效 */
    private fun applyBackground() {
        val host = bgHost ?: return
        host.removeAllViews()
        val match = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )

        fun addImage(d: Drawable) {
            host.addView(ImageView(app).apply {
                setImageDrawable(d)
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = match
            })
        }

        val name = Config.background(app)
        val gradient = BG_GRADIENTS[name]
        when {
            gradient != null -> host.addView(View(app).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM, gradient
                )
                layoutParams = match
            })

            name == BG_CUSTOM || name == BG_WEB -> {
                val bmp = if (name == BG_WEB) loadWebBg() ?: loadCustomBg() else loadCustomBg()
                if (bmp != null) {
                    addImage(android.graphics.drawable.BitmapDrawable(app.resources, bmp))
                } else {
                    // 不再回退到内置 gay 图片；没有可用图片时保持深色背景。
                    host.addView(View(app).apply {
                        background = GradientDrawable(
                            GradientDrawable.Orientation.TOP_BOTTOM,
                            BG_GRADIENTS["深色"]!!
                        )
                        layoutParams = match
                    })
                }
            }

            else -> host.addView(View(app).apply {
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    BG_GRADIENTS["深色"]!!
                )
                layoutParams = match
            })
        }
    }

    private fun buildNavItems(container: LinearLayout) {
        val names = listOf(
            "杂项",
            "设置"
        )

        names.forEachIndexed { index, name ->
            container.addView(buildNavItem(name, index))
        }
    }

    private fun buildNavItem(
        name: String,
        index: Int
    ): View {
        val active = index == selectedTab
        val color = if (active) activeColor else inactiveColor

        if (navIsVertical) {
            val row = LinearLayout(app).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(42f)
                )
                setOnClickListener {
                    onNavClicked(index)
                }
            }

            val line = View(app).apply {
                setBackgroundColor(
                    if (active) activeColor
                    else Color.TRANSPARENT
                )
                layoutParams = LinearLayout.LayoutParams(
                    dp(3f),
                    LinearLayout.LayoutParams.MATCH_PARENT
                )
            }
            row.addView(line)
            navLines.add(line)

            val dot = View(app).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(1.5f), color)
                }
                layoutParams =
                    LinearLayout.LayoutParams(
                        dp(16f),
                        dp(16f)
                    ).apply {
                        leftMargin = dp(14f)
                    }
            }
            row.addView(dot)
            navDots.add(dot)

            val text = TextView(app).apply {
                this.text = name
                setTextColor(color)
                textSize = 13f
                layoutParams =
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        leftMargin = dp(12f)
                    }
            }
            row.addView(text)
            navTexts.add(text)

            return row
        } else {
            val tv = TextView(app).apply {
                this.text = name
                setTextColor(color)
                textSize = 12f
                gravity = Gravity.CENTER
                layoutParams =
                    LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.MATCH_PARENT
                    ).apply {
                        weight = 1f
                        leftMargin = dp(4f)
                        rightMargin = dp(4f)
                    }
                setOnClickListener {
                    onNavClicked(index)
                }
            }
            navTexts.add(tv)
            return tv
        }
    }

    private fun onNavClicked(index: Int) {
        if (index == selectedTab) return
        if (isAnimatingTab) return

        val oldIndex = selectedTab
        selectedTab = index
        isAnimatingTab = true

        updateNavColors()
        moveCapsule(index)
        switchContent(oldIndex, index)
    }

    private fun moveCapsule(index: Int) {
        val capsule = navCapsule ?: return
        val container = navContainer ?: return
        if (navIsVertical) return

        // 直接拿第 index 个 Tab 的真实位置和宽度
        val target = container.getChildAt(index)
        if (target == null) return

        val lp = capsule.layoutParams as FrameLayout.LayoutParams
        lp.width = target.width
        lp.height = target.height - dp(8f)
        capsule.layoutParams = lp

        capsule.visibility = View.VISIBLE

        // container 在 topNavWrapper 里的 x 坐标是固定的（0 或 paddingLeft）
        val targetX = target.left.toFloat() - container.paddingLeft + dp(4f)

        capsule.animate()
            .translationX(targetX)
            .setDuration(280)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()
    }

    private fun updateNavColors() {
        navTexts.forEachIndexed { i, tv ->
            tv.setTextColor(
                if (i == selectedTab) activeColor
                else inactiveColor
            )
        }

        navLines.forEachIndexed { i, line ->
            line.setBackgroundColor(
                if (i == selectedTab) activeColor
                else Color.TRANSPARENT
            )
        }

        navDots.forEachIndexed { i, dot ->
            dot.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(
                    dp(1.5f),
                    if (i == selectedTab) activeColor
                    else inactiveColor
                )
            }
        }
    }

    private fun switchContent(
        oldIndex: Int,
        newIndex: Int
    ) {
        val container = contentFlipper ?: run {
            isAnimatingTab = false
            return
        }

        // 直接替换内容容器中的页面，不再使用 ViewFlipper。
        // 这样切换到“设置”时一定会重新布局并显示对应内容。
        container.removeAllViews()

        val newView = buildContentArea().apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            visibility = View.VISIBLE
            alpha = 1f
        }

        container.addView(newView)
        newView.bringToFront()
        container.bringToFront()
        container.requestLayout()
        container.invalidate()

        isAnimatingTab = false
    }

    private fun buildTitleBar(): View {
        val bar = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14f), 0, dp(10f), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(46f)
            )
        }

        val title = TextView(app).apply {
            text = "Clans"
            setTextColor(activeColor)
            textSize = 16f
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT
            ).apply {
                weight = 1f
            }
        }

        val close = TextView(app).apply {
            text = "×"
            setTextColor(inactiveColor)
            textSize = 24f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                dp(42f),
                dp(42f)
            )
            setOnClickListener { hidePanel() }
        }

        bar.addView(title)
        bar.addView(close)
        return bar
    }

    private fun makeDivider(): View {
        return View(app).apply {
            setBackgroundColor(
                Color.parseColor("#33FFFFFF")
            )
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(1f)
            )
        }
    }

    private fun buildContentArea(): View {
        var swipeDownX = 0f
        var swipeDownY = 0f
        var horizontalSwipe = false
        val scroll = ScrollView(app).apply {
            isFillViewport = true
            visibility = View.VISIBLE
            alpha = 1f
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            // 在内容区域左右滑动切换“杂项 / 设置”；普通点击和上下滚动仍交给子控件。
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        swipeDownX = event.x
                        swipeDownY = event.y
                        horizontalSwipe = false
                        false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.x - swipeDownX
                        val dy = event.y - swipeDownY
                        if (kotlin.math.abs(dx) > dp(48f) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                            horizontalSwipe = true
                            view.parent?.requestDisallowInterceptTouchEvent(true)
                        }
                        horizontalSwipe
                    }
                    MotionEvent.ACTION_UP -> {
                        val dx = event.x - swipeDownX
                        val dy = event.y - swipeDownY
                        val isSwipe = horizontalSwipe || (kotlin.math.abs(dx) > dp(64f) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f)
                        if (isSwipe) {
                            val target = if (dx < 0f) 1 else 0
                            if (target != selectedTab) onNavClicked(target)
                            view.parent?.requestDisallowInterceptTouchEvent(false)
                            true
                        } else {
                            false
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        horizontalSwipe = false
                        view.parent?.requestDisallowInterceptTouchEvent(false)
                        false
                    }
                    else -> false
                }
            }
        }

        val content = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                dp(14f),
                dp(12f),
                dp(14f),
                dp(12f)
            )
        }

        when (selectedTab) {
            0 -> {
                content.addView(sectionTitle("环境"))
                content.addView(plainText("扫码登录所需的 MuMu 环境"))
                content.addView(gap(8f))
                content.addView(featureRow(Feature.MUMU_SPOOF))
            }
            else -> {
                content.addView(sectionTitle("设置"))
                content.addView(plainText("开关即改即存，重启游戏依然保留"))
                content.addView(gap(8f))
                content.addView(
                    dropdownRow("面板背景", BG_OPTIONS, { Config.background(app) }) {
                        if (it == BG_WEB) {
                            fetchRandomWebBackground()
                        } else {
                            Config.setBackground(app, "深色")
                            applyBackground()
                            switchContent(selectedTab, selectedTab)
                        }
                    }
                )
                content.addView(gap(6f))
                content.addView(featureRow(Feature.INJECT_TOAST))
                content.addView(gap(12f))
                content.addView(closeServiceRow())
            }
        }

        scroll.addView(content)
        return scroll
    }

    private fun actionRow(title: String, subtitle: String, action: () -> Unit): View {
        val row = LinearLayout(app).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), dp(7f), dp(10f), dp(7f))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52f))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2215101A"))
                cornerRadius = dp(8f).toFloat()
                setStroke(dp(1f), Color.parseColor("#33FF82BE"))
            }
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        row.addView(TextView(app).apply {
            text = title
            setTextColor(activeColor)
            textSize = 13f
        })
        row.addView(TextView(app).apply {
            text = subtitle
            setTextColor(inactiveColor)
            textSize = 10f
        })
        return row
    }

    private fun sectionTitle(text: String): View {
        return TextView(app).apply {
            this.text = text
            setTextColor(activeColor)
            textSize = 15f
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(36f)
            )
        }
    }

    private fun plainText(text: String): View {
        return TextView(app).apply {
            this.text = text
            setTextColor(inactiveColor)
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun gap(heightDp: Float): View {
        return View(app).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(heightDp)
            )
        }
    }

    /**
     * 功能开关行。
     *
     * 重点：状态是**持久化**的 —— 写进游戏自己的 clans_module.xml，
     * 真正的游戏逻辑用 Config.isOn(ctx, feature) 读它。
     * （以前这里的 ON/OFF 只存在内存里，切换 Tab 重建视图就丢了，
     *   而且没有任何代码能读到它，纯装饰。）
     *
     * 锁定项（[Feature.locked]）走 [lockedRow]：只占位、不可点，
     * 因为它的效果是无条件的，面板上不该给关闭入口。
     */
    private fun featureRow(f: Feature): View =
        if (f.locked) lockedRow(f.label) else switchRow(f.label, f)

    /**
     * 「固定开启」的占位行。
     *
     * 和 [switchRow] 长得一样，区别是：
     *   · 右侧固定显示「固定开启」，颜色用 activeColor（一致表示「生效中」）
     *   · **不挂 OnClickListener** —— LinearLayout 默认就不可点，所以点它没有任何反应，
     *     也不会有水波纹/按压态，用户一眼就能看出这行不是开关
     * （不是把开关禁掉，而是压根没有开关：`Feature.locked` 的项在代码层面
     *   也没有任何读取/写入偏好的路径。）
     */
    private fun lockedRow(label: String): View {
        val row = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(10f), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44f)
            )
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2215101A"))
                cornerRadius = dp(8f).toFloat()
            }
        }

        val text = TextView(app).apply {
            this.text = label
            setTextColor(inactiveColor)
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT
            ).apply {
                weight = 1f
            }
        }

        val state = TextView(app).apply {
            // 必须写 this.text：上面那个局部变量就叫 text（TextView 类型），
            // 在 apply 里会**遮蔽**接收者的 text 属性，写成 text = "..." 会变成
            // 「给 val 重新赋值」而报 'val' cannot be reassigned。
            // （上面那段用 this.text = label 就是为了防这个，这段我之前漏了。）
            this.text = "固定开启"
            setTextColor(activeColor)
            textSize = 11f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                dp(72f),
                dp(30f)
            )
        }

        row.addView(text)
        row.addView(state)
        return row
    }

    private fun switchRow(label: String, feature: Feature? = null): View {
        val row = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(10f), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44f)
            )
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2215101A"))
                cornerRadius = dp(8f).toFloat()
            }
        }

        val text = TextView(app).apply {
            this.text = label
            setTextColor(inactiveColor)
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT
            ).apply {
                weight = 1f
            }
        }

        val state = TextView(app).apply {
            setTextColor(inactiveColor)
            textSize = 11f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                dp(48f),
                dp(30f)
            )
        }

        // 初始状态从配置读，不再固定 OFF
        var enabled = feature != null && Config.isOn(app, feature)

        fun render() {
            state.text = if (enabled) "ON" else "OFF"
            state.setTextColor(if (enabled) activeColor else inactiveColor)
        }
        render()

        row.setOnClickListener {
            enabled = !enabled
            if (feature != null) Config.setOn(app, feature, enabled)
            render()
        }

        row.addView(text)
        row.addView(state)
        return row
    }

    private fun closeServiceRow(): View {
        val row = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(10f), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44f)
            )
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2215101A"))
                cornerRadius = dp(8f).toFloat()
                setStroke(dp(1f), Color.parseColor("#66FF82BE"))
            }
            setOnClickListener {
                onUserClosed?.invoke()
                destroy()
            }
        }

        val label = TextView(app).apply {
            text = "关闭悬浮窗"
            setTextColor(activeColor)
            textSize = 13f
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT
            ).apply {
                weight = 1f
            }
        }

        row.addView(label)
        return row
    }

    /**
     * 透明度滑杆：左右拖动改 20%~100%，实时改面板 alpha 并持久化。
     * （以前只是个写着 "80%" 的静态文本，拖不动也不生效。）
     */
    private fun sliderRow(
        label: String,
        initial: Float,
        onChanged: (Float) -> Unit
    ): View {
        val row = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(10f), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44f)
            )
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2215101A"))
                cornerRadius = dp(8f).toFloat()
            }
        }

        val text = TextView(app).apply {
            this.text = label
            setTextColor(inactiveColor)
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
            }
        }

        val value = TextView(app).apply {
            this.text = "${(initial * 100).toInt()}%"
            setTextColor(activeColor)
            textSize = 12f
        }

        row.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_MOVE -> {
                    val w = view.width.coerceAtLeast(1)
                    val ratio = (event.x / w).coerceIn(MIN_OPACITY, 1f)
                    // 按 5% 一档，避免抖动
                    val v = (Math.round(ratio * 20f) / 20f)
                        .coerceIn(MIN_OPACITY, 1f)
                    value.text = "${(v * 100).toInt()}%"
                    onChanged(v)
                    true
                }

                MotionEvent.ACTION_UP -> {
                    // DOWN 已经消费了事件，UP 也一并吃掉，别漏给下面的滚动容器
                    view.performClick()
                    true
                }

                else -> false
            }
        }

        row.addView(text)
        row.addView(value)
        return row
    }

    /** 下拉行：点一下往后切一个，切了就持久化 */
    private fun dropdownRow(
        label: String,
        options: List<String>,
        current: () -> String,
        onPick: (String) -> Unit
    ): View {
        val row = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(10f), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44f)
            )
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2215101A"))
                cornerRadius = dp(8f).toFloat()
            }
        }

        val labelView = TextView(app).apply {
            text = label
            setTextColor(inactiveColor)
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
            }
        }

        fun currentIndex(): Int {
            val i = options.indexOf(current())
            return if (i < 0) 0 else i
        }

        val valueView = TextView(app).apply {
            text = options[currentIndex()]
            setTextColor(activeColor)
            textSize = 12f
        }

        row.setOnClickListener {
            val next = options[(currentIndex() + 1) % options.size]
            valueView.text = next
            onPick(next)
        }

        row.addView(labelView)
        row.addView(valueView)
        return row
    }

    private fun buildBottomBar(): View {
        val bar = LinearLayout(app).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12f), 0, dp(12f), 0)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(44f)
            )
        }

        val status = TextView(app).apply {
            text = "Ready"
            setTextColor(inactiveColor)
            textSize = 11f
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.MATCH_PARENT
            ).apply {
                weight = 1f
            }
        }

        bar.addView(status)
        return bar
    }
}
