package com.example.myno.clans.modern

import com.example.myno.clans.hook.Config
import com.example.myno.clans.hook.XLog
import io.github.libxposed.api.XposedModule
import io.github.libxposed.api.XposedModuleInterface.ModuleLoadedParam
import io.github.libxposed.api.XposedModuleInterface.PackageLoadedParam
import io.github.libxposed.api.XposedModuleInterface.PackageReadyParam

/**
 * ============ 现代管线入口（Xposed API 101 / 102，io.github.libxposed）============
 *
 * 由 APK 里的 `META-INF/xposed/java_init.list` 声明：
 *     com.example.myno.clans.modern.ClansModernModule
 *
 * 什么时候会被用到：
 *   · 框架支持 MODERN 管线（LSPosed 新版 / NPatch），且模块声明了
 *     `xposedtargetversion` >= 101 —— 我们声明的是 102；
 *   · LSPosed/NPatch 的判定见 VersionRouter：
 *       minApiVersion <= 102 && targetApiVersion >= 101 && 有现代入口 → MODERN
 *
 * 什么时候**不会**被用到：
 *   · 老的 LSPatch 0.7（core API 93，根本不认识 META-INF/xposed/），
 *     它只读 manifest 的 xposedminversion 和 assets/xposed_init，
 *     于是走 [com.example.myno.clans.hook.ClansModule] 那条传统管线。
 *
 * ⚠️ 铁律：**这条代码路径上不能出现任何 de.robv.android.xposed.* 的静态引用**。
 * targetApiVersion >= 102 时，框架的模块 ClassLoader 会对这些名字直接抛
 * ClassNotFoundException（VectorModuleClassLoader.loadClass），
 * 一旦类校验阶段触发就会把入口带崩。所以：
 *   · 日志走 XLog（内部只用 Class.forName 字符串查找）
 *   · hook 全部用现代 API 的 hook(Executable).intercept(Hooker)
 *   · 不再依赖 XposedHelpers / XC_MethodHook / XModuleResources
 */
class ClansModernModule : XposedModule() {

    init {
        // 越早越好：ModuleResources / XLog 会据此切到现代分支
        Config.modernApi = true
    }

    override fun onModuleLoaded(param: ModuleLoadedParam) {
        Config.modernApi = true

        // 把框架日志接进 XLog，两种管线的日志行为就一致了
        XLog.bindModern { priority, tag, msg, tr ->
            if (tr != null) log(priority, tag, msg, tr) else log(priority, tag, msg)
        }

        XLog.i(
            "Modern[${getFrameworkName()} ${getFrameworkVersion()} / API ${getApiVersion()}]: " +
                    "onModuleLoaded process=${param.processName} systemServer=${param.isSystemServer()}"
        )

        // 现代 API 能直接拿到模块自己的 ApplicationInfo —— 内嵌模式下也能定位模块资源
        try {
            val ai = getModuleApplicationInfo()
            Config.moduleApkPath = ai.sourceDir
            Config.modulePath = ai.sourceDir
            XLog.i("Modern: 模块 APK = ${ai.sourceDir} (pkg=${ai.packageName})")
        } catch (t: Throwable) {
            XLog.e("Modern: 取模块 ApplicationInfo 失败（资源将走 createPackageContext 兜底）", t)
        }
    }

    override fun onPackageLoaded(param: PackageLoadedParam) {
        if (!Config.isTarget(param.packageName)) return
        // getDefaultClassLoader() 标了 @RequiresApi(Q)，低版本上别去碰
        val defaultCl: Any =
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                param.defaultClassLoader
            } else {
                "n/a(Android < 10)"
            }
        XLog.i(
            "Modern: onPackageLoaded pkg=${param.packageName} first=${param.isFirstPackage()} " +
                    "defaultClassLoader=$defaultCl"
        )
    }

    override fun onPackageReady(param: PackageReadyParam) {
        val pkg = param.packageName

        // ---- MuMu 环境模拟：不挑包名，作用域内每个进程都装（和原模块行为一致） ----
        try {
            ModernMumuSpoof.install(this, param.classLoader)
        } catch (t: Throwable) {
            XLog.e("Modern: MumuSpoof 安装失败", t)
        }

        // 悬浮窗只装进目标游戏
        if (!Config.isTarget(pkg)) return

        XLog.i("Modern: onPackageReady pkg=$pkg first=${param.isFirstPackage()}")
        try {
            ModernInstaller.install(this, param.classLoader)
        } catch (t: Throwable) {
            XLog.e("Modern: 安装悬浮窗失败", t)
        }
    }
}
