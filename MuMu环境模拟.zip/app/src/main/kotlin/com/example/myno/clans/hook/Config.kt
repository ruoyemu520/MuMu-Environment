package com.example.myno.clans.hook

import android.content.Context
import android.content.SharedPreferences

/**
 * 模块配置。
 *
 * ⚠️ 进程模型很关键：模块被注入后，我们的代码跑在**目标游戏进程**里，
 * UID 就是游戏的 UID，所以读不到模块自己 App 的私有 SharedPreferences
 * （那是另一个 UID 的文件）。因此配置直接写进游戏自己的
 * MODE_PRIVATE 偏好文件 clans_module.xml：
 *   · 不需要任何权限
 *   · 不需要 XSharedPreferences 那套世界可读的绕法
 *   · 游戏卸载时自动清理
 * 代价是：模块 App 主界面（另一个进程）看不到也改不了这些值，
 * 所以开关只在**游戏内的悬浮面板**上操作。
 */
object Config {

    const val MODULE_PACKAGE = "com.example.myno.clans"

    /** 目标游戏（国服 + 华为渠道包，同一份代码） */
    val TARGET_PACKAGES = setOf("com.netease.tom", "com.netease.tom.huawei")

    /** 游戏主 Activity（Cocos2d-x Lua 引擎），悬浮窗就挂它的 decorView */
    const val TARGET_ACTIVITY = "org.cocos2dx.lua.AppActivity"

    fun isTarget(pkg: String?): Boolean = pkg != null && TARGET_PACKAGES.contains(pkg)

    private const val PREFS = "clans_module"

    /** initZygote 拿到的模块 APK 路径；LSPatch 本地模式下可能拿不到 */
    @Volatile
    var modulePath: String? = null

    /**
     * 模块自己 APK 的路径。现代管线（API 101/102）由 ClansModernModule 从
     * XposedInterface.getModuleApplicationInfo().sourceDir 填进来，
     * 用于在「模块 App 没被单独安装」（LSPatch/NPatch 内嵌模式）时解析模块资源。
     */
    @Volatile
    var moduleApkPath: String? = null

    /** 是否跑在现代管线（io.github.libxposed / API 101+）下 */
    @Volatile
    var modernApi: Boolean = false

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------- 悬浮窗挂载方式 ----------------
    //
    // 「悬浮窗模式」这个设置项已经**删掉**了（用户要求），所以这里不再有
    // MODE_DECOR / MODE_WINDOW / overlay_mode 那一堆常量和读写函数。
    // 现在只剩一种行为，写死在 Installer.onResumed() 里：
    //   优先 decor（塞进游戏 Activity 的 decorView，**不需要悬浮窗权限**），
    //   失败才回退到 window（系统悬浮窗，需要游戏自己拿到权限）。
    // 之所以优先 decor：被 NPatch/LSPatch 打过补丁的游戏通常**没有**
    // SYSTEM_ALERT_WINDOW，走系统悬浮窗会直接 BadTokenException。

    // ---------------- 功能开关 ----------------
    fun isOn(ctx: Context, f: Feature): Boolean = prefs(ctx).getBoolean(f.key, f.defaultOn)

    fun setOn(ctx: Context, f: Feature, on: Boolean) {
        prefs(ctx).edit().putBoolean(f.key, on).apply()
    }

    // ---------------- 配置页那两个占位控件，现在真存值了 ----------------
    /** 面板不透明度。默认 1f = 100%（不透明），用户拖滑杆可以调低 */
    fun opacity(ctx: Context): Float = prefs(ctx).getFloat(KEY_OPACITY, 1f)

    fun setOpacity(ctx: Context, v: Float) {
        prefs(ctx).edit().putFloat(KEY_OPACITY, v).apply()
    }

    fun scheme(ctx: Context): String = prefs(ctx).getString(KEY_SCHEME, DEFAULT_SCHEME) ?: DEFAULT_SCHEME

    fun setScheme(ctx: Context, v: String) {
        prefs(ctx).edit().putString(KEY_SCHEME, v).apply()
    }

    const val DEFAULT_SCHEME = "默认"

    /** 面板背景：名字见 OverlayController.BG_OPTIONS */
    const val DEFAULT_BG = "深色"

    fun background(ctx: Context): String =
        prefs(ctx).getString(KEY_BG, DEFAULT_BG) ?: DEFAULT_BG

    fun setBackground(ctx: Context, v: String) {
        prefs(ctx).edit().putString(KEY_BG, v).apply()
    }

    private const val KEY_BG = "panel_bg"

    private const val KEY_OPACITY = "opacity"
    private const val KEY_SCHEME = "scheme"
}

/**
 * 悬浮面板上的开关 ↔ 配置项。
 * 面板里点一下就会持久化，真正的游戏逻辑 hook 去读这些值。
 */
enum class Feature(
    val key: String,
    val label: String,
    val defaultOn: Boolean = false,
    /**
     * 锁定项：**永远生效，面板上没有关闭入口**，只做占位展示。
     * 杂项页的「MuMu 环境」就是这种（用户明确要求它不可关闭）。
     */
    val locked: Boolean = false
) {
    /**
     * 模拟 MuMu 模拟器环境（从「网易MuMu模拟」模块移植）。
     *
     * **锁定开启、不可关闭**（按用户要求）：两条管线里的 hook 都无条件生效，
     * 不再读任何偏好值。也就是说历史版本存过的 `mumu_spoof=false` 不会再生效，
     * 升级后自动恢复伪装，不需要用户去清 clans_module.xml。
     * 面板「杂项」页保留这一行做**占位展示**，右侧固定显示「固定开启」，点不动。
     *
     * `locked = true` 是给面板用的：`featureRow()` 见到锁定项就渲染成不可点的
     * 静态行，而不是开关行。`key`/`defaultOn` 现在只是为了兼容旧配置而留着。
     */
    MUMU_SPOOF("mumu_spoof", "MuMu 环境", true, locked = true),
    /** 注入成功时弹个 Toast，确认模块真的生效了 */
    INJECT_TOAST("inject_toast", "注入提示", true);
}
