package com.example.myno.clans.hook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.callbacks.XC_LoadPackage

/**
 * 模块入口类。
 *
 * ⚠️ 这个类名必须和 assets/xposed_init 里的那一行**完全一致**，
 *    改动这里就要同步改 xposed_init，否则模块静默失效。
 */
class ClansModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam) {
        // 拿到模块 APK 自身路径，后面解析模块资源（悬浮窗图片）时可能用得上。
        // LSPatch 本地模式下不一定会走到这里，所以下游都有兜底。
        Config.modulePath = startupParam.modulePath
        XLog.i("initZygote: modulePath=${Config.modulePath}")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // ---- MuMu 环境模拟：不挑包名，作用域内每个进程都装 ----
        // 原模块「网易MuMu模拟」也是不判包名的（它的 handleLoadPackage 里连包名都没读），
        // 这里保持一致；作用域由 manifest 的 xposedscope / META-INF/xposed/scope.list 决定。
        try {
            MumuSpoof.install(lpparam.classLoader)
        } catch (t: Throwable) {
            XLog.e("MumuSpoof 安装失败", t)
        }

        // 只把**悬浮窗**装进目标游戏，其它 App 一律放过（作用域没勾也拦一道，安全）
        if (!Config.isTarget(lpparam.packageName)) return

        XLog.i("注入成功: pkg=${lpparam.packageName} process=${lpparam.processName}")

        try {
            Installer.install(lpparam)
        } catch (t: Throwable) {
            XLog.e("模块安装失败", t)
        }
    }
}
