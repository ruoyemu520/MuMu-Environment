package com.example.myno.clans

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.myno.clans.overlay.OverlayController

/**
 * 「本机预览」用：在模块自己的 App 里把悬浮窗画出来，方便不启动游戏就调界面。
 *
 * 注入到目标游戏时**不会**用到这个 Service —— 那边由 Installer 直接
 * new 一个 OverlayController 挂进游戏进程，不需要前台服务也不需要通知。
 */
class FloatingService : Service() {

    private var controller: OverlayController? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        // 这里传的 resources 就是模块自己的资源，预览时图片能正常显示
        controller = OverlayController.forWindow(this, resources)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        controller?.destroy()
        controller = null
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        val channelId = "clans_floating"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Clans 悬浮窗预览",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val closeIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, FloatingService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification =
            NotificationCompat.Builder(this, channelId)
                .setContentTitle("Clans 悬浮窗预览中")
                .setContentText("点此关闭悬浮窗")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentIntent(closeIntent)
                .setOngoing(true)
                .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                1001,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(1001, notification)
        }
    }

    companion object {
        const val ACTION_STOP = "com.example.myno.clans.ACTION_STOP"
    }
}
