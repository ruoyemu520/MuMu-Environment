#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
纯 Python 的 DEX 逆向小工具（这台设备上没有 jadx / dexdump / aapt）。

能做的：
  · 列出所有类、父类、访问标志
  · 列出每个类的方法/字段（名字 + 签名）
  · 把每个方法的字节码里 `const-string` 用到的字符串**按方法归类** dump 出来
    —— 逆向 Xposed 模块时这一条最有用：hook 的目标类名/方法名、
       日志文案、SharedPreferences key、设置项标题，全都在这些常量里

不支持：控制流还原、反编译成 Java。够用就行。
"""
import struct, sys

# 标准 dex 039 指令长度表（单位：16-bit code unit）
LEN = {
    0x00:1,0x01:1,0x02:2,0x03:3,0x04:1,0x05:2,0x06:3,0x07:1,0x08:2,0x09:3,
    0x0a:1,0x0b:1,0x0c:1,0x0d:1,0x0e:1,0x0f:1,0x10:1,0x11:1,0x12:1,0x13:2,
    0x14:3,0x15:2,0x16:2,0x17:3,0x18:5,0x19:2,0x1a:2,0x1b:3,0x1c:2,0x1d:1,
    0x1e:1,0x1f:2,0x20:2,0x21:1,0x22:2,0x23:2,0x24:3,0x25:3,0x26:3,0x27:1,
    0x28:1,0x29:2,0x2a:3,0x2b:3,0x2c:3,0x2d:2,0x2e:2,0x2f:2,0x30:2,0x31:2,
    0x32:2,0x33:2,0x34:2,0x35:2,0x36:2,0x37:2,0x38:2,0x39:2,0x3a:2,0x3b:2,
    0x3c:2,0x3d:2,0x3e:1,0x3f:1,0x40:1,0x41:1,0x42:1,0x43:1,
    0x44:2,0x45:2,0x46:2,0x47:2,0x48:2,0x49:2,0x4a:2,0x4b:2,0x4c:2,0x4d:2,
    0x4e:2,0x4f:2,0x50:2,0x51:2,0x52:2,0x53:2,0x54:2,0x55:2,0x56:2,0x57:2,
    0x58:2,0x59:2,0x5a:2,0x5b:2,0x5c:2,0x5d:2,0x5e:2,0x5f:2,
    0x60:2,0x61:2,0x62:2,0x63:2,0x64:2,0x65:2,0x66:2,0x67:2,0x68:2,0x69:2,
    0x6a:2,0x6b:2,0x6c:2,0x6d:2,0x6e:3,0x6f:3,0x70:3,0x71:3,0x72:3,
    0x73:1,0x74:3,0x75:3,0x76:3,0x77:3,0x78:3,0x79:1,0x7a:1,
    0x7b:1,0x7c:1,0x7d:1,0x7e:1,0x7f:1,0x80:1,0x81:1,0x82:1,0x83:1,0x84:1,
    0x85:1,0x86:1,0x87:1,0x88:1,0x89:1,0x8a:1,0x8b:1,0x8c:1,0x8d:1,0x8e:1,
    0x8f:1,0x90:1,0x91:1,0x92:1,0x93:1,0x94:1,0x95:1,0x96:1,0x97:1,0x98:1,
    0x99:1,0x9a:1,0x9b:1,0x9c:1,0x9d:1,0x9e:1,0x9f:1,0xa0:1,0xa1:1,0xa2:1,
    0xa3:1,0xa4:1,0xa5:1,0xa6:1,0xa7:1,0xa8:1,0xa9:1,0xaa:1,0xab:1,0xac:1,
    0xad:1,0xae:1,0xaf:1,0xb0:1,0xb1:1,0xb2:1,0xb3:1,0xb4:1,0xb5:1,0xb6:1,
    0xb7:1,0xb8:1,0xb9:1,0xba:1,0xbb:1,0xbc:1,0xbd:1,0xbe:1,0xbf:1,0xc0:1,
    0xc1:1,0xc2:1,0xc3:1,0xc4:1,0xc5:1,0xc6:1,0xc7:1,0xc8:1,0xc9:1,0xca:1,
    0xcb:1,0xcc:1,0xcd:1,0xce:1,0xcf:1,0xd0:2,0xd1:2,0xd2:2,0xd3:2,0xd4:2,
    0xd5:2,0xd6:2,0xd7:2,0xd8:2,0xd9:2,0xda:2,0xdb:2,0xdc:2,0xdd:2,0xde:2,
    0xdf:2,0xe0:2,0xe1:2,0xe2:2,
    0xfa:4,0xfb:4,0xfc:3,0xfd:3,0xfe:2,0xff:2,
}


def uleb(d, off):
    r = 0; sh = 0
    while True:
        b = d[off]; off += 1
        r |= (b & 0x7f) << sh
        if not (b & 0x80):
            return r, off
        sh += 7


def sleb(d, off):
    r = 0; sh = 0
    while True:
        b = d[off]; off += 1
        r |= (b & 0x7f) << sh
        sh += 7
        if not (b & 0x80):
            if b & 0x40:
                r |= -(1 << sh)
            return r, off


def mutf8(d, off):
    n, p = uleb(d, off)
    out = bytearray()
    while d[p] != 0:
        out.append(d[p]); p += 1
    return out.decode('utf-8', 'replace'), p + 1


class Dex:
    def __init__(self, data):
        self.d = data
        (self.string_ids_size, self.string_ids_off) = struct.unpack('<II', data[56:64])
        (self.type_ids_size, self.type_ids_off) = struct.unpack('<II', data[64:72])
        (self.proto_ids_size, self.proto_ids_off) = struct.unpack('<II', data[72:80])
        (self.field_ids_size, self.field_ids_off) = struct.unpack('<II', data[80:88])
        (self.method_ids_size, self.method_ids_off) = struct.unpack('<II', data[88:96])
        (self.class_defs_size, self.class_defs_off) = struct.unpack('<II', data[96:104])
        self._str = {}

    def string(self, i):
        if i not in self._str:
            off = struct.unpack('<I', self.d[self.string_ids_off + 4 * i:
                                             self.string_ids_off + 4 * i + 4])[0]
            self._str[i] = mutf8(self.d, off)[0]
        return self._str[i]

    def type(self, i):
        di = struct.unpack('<I', self.d[self.type_ids_off + 4 * i:
                                        self.type_ids_off + 4 * i + 4])[0]
        return self.string(di)

    def proto(self, i):
        shorty_idx, ret, params_off = struct.unpack(
            '<III', self.d[self.proto_ids_off + 12 * i: self.proto_ids_off + 12 * i + 12])
        args = []
        if params_off:
            n = struct.unpack('<I', self.d[params_off:params_off + 4])[0]
            for k in range(n):
                ti = struct.unpack('<H', self.d[params_off + 4 + 2 * k:
                                              params_off + 6 + 2 * k])[0]
                args.append(self.type(ti))
        return args, self.type(ret)

    def field(self, i):
        c, t, n = struct.unpack('<HHI', self.d[self.field_ids_off + 8 * i:
                                               self.field_ids_off + 8 * i + 8])
        return self.type(c), self.type(t), self.string(n)

    def method(self, i):
        c, p, n = struct.unpack('<HHI', self.d[self.method_ids_off + 8 * i:
                                               self.method_ids_off + 8 * i + 8])
        return self.type(c), self.proto(p), self.string(n)

    def methods_of(self, class_data_off):
        """返回 (direct, virtual)，每项 = (method_idx, access, code_off)"""
        if not class_data_off:
            return [], [], [], []
        o = class_data_off
        sf, o = uleb(self.d, o)
        inf, o = uleb(self.d, o)
        dm, o = uleb(self.d, o)
        vm, o = uleb(self.d, o)
        def fields(n):
            nonlocal o
            out = []; idx = 0
            for _ in range(n):
                diff, o = uleb(self.d, o); acc, o = uleb(self.d, o)
                idx += diff; out.append((idx, acc))
            return out
        sfields = fields(sf)
        ifields = fields(inf)
        def methods(n):
            nonlocal o
            out = []; idx = 0
            for _ in range(n):
                diff, o = uleb(self.d, o); acc, o = uleb(self.d, o)
                co, o = uleb(self.d, o)
                idx += diff; out.append((idx, acc, co))
            return out
        dms = methods(dm)
        vms = methods(vm)
        return sfields, ifields, dms, vms

    def const_strings(self, code_off):
        """扫一个 code_item 的字节码，收集 const-string 引用的字符串"""
        if not code_off:
            return []
        o = code_off
        regs, ins, outs, tries, dbg, insns_size = struct.unpack('<HHHHII', self.d[o:o+16])
        insns = o + 16
        out = []
        i = 0
        while i < insns_size:
            u = struct.unpack('<H', self.d[insns + 2 * i: insns + 2 * i + 2])[0]
            op = u & 0xff
            if op == 0x00 and u != 0:
                # packed-switch / sparse-switch 的 payload
                if u == 0x0100:
                    # 布局：ident(1) + size(1) + first_key(2) + size×target(2 each)
                    # 单位数 = 4 + 2*size（以前的 size+2 是错的，会读飞）
                    size = struct.unpack('<H', self.d[insns + 2 * i + 2:
                                                      insns + 2 * i + 4])[0]
                    i += 4 + 2 * size
                    continue
                if u == 0x0200:
                    # 布局：ident(1) + size(1) + size×(key 2 + target 2)
                    # 单位数 = 2 + 4*size
                    size = struct.unpack('<H', self.d[insns + 2 * i + 2:
                                                      insns + 2 * i + 4])[0]
                    i += 2 + 4 * size
                    continue
                if u == 0x0300:  # fill-array-data
                    esize = struct.unpack('<H', self.d[insns + 2 * i + 2:
                                                       insns + 2 * i + 4])[0]
                    n = struct.unpack('<I', self.d[insns + 2 * i + 4:
                                                   insns + 2 * i + 8])[0]
                    i += (n * esize + 1) // 2 + 4
                    continue
            n = LEN.get(op)
            if n is None:
                break
            if op == 0x1a:
                si = struct.unpack('<H', self.d[insns + 2 * i + 2:
                                                insns + 2 * i + 4])[0]
                out.append(self.string(si))
            elif op == 0x1b:
                si = struct.unpack('<I', self.d[insns + 2 * i + 2:
                                                insns + 2 * i + 6])[0]
                out.append(self.string(si))
            i += n
        return out

    def classes(self):
        for i in range(self.class_defs_size):
            base = self.class_defs_off + 32 * i
            (cidx, acc, superidx, ifaces, src, anno, cdata, sval) = struct.unpack(
                '<IIIIIIII', self.d[base:base + 32])
            yield {
                'name': self.type(cidx),
                'acc': acc,
                'super': self.type(superidx) if superidx != 0xffffffff else None,
                'src': self.string(src) if src != 0xffffffff else None,
                'cdata': cdata,
            }


if __name__ == '__main__':
    path = sys.argv[1]
    mode = sys.argv[2] if len(sys.argv) > 2 else 'all'
    filt = sys.argv[3] if len(sys.argv) > 3 else None
    dx = Dex(open(path, 'rb').read())
    print('# %s : %d 个类, %d 个字符串' % (path, dx.class_defs_size, dx.string_ids_size))
    for c in dx.classes():
        if filt and filt not in c['name']:
            continue
        print('\n=== %s %s' % (c['name'], ('extends ' + c['super']) if c['super'] else ''))
        sf, inf, dms, vms = dx.methods_of(c['cdata'])
        if mode in ('all', 'fields'):
            for idx, acc in sf:
                cl, t, n = dx.field(idx)
                print('    static  %-40s %s' % (t, n))
            for idx, acc in inf:
                cl, t, n = dx.field(idx)
                print('    field   %-40s %s' % (t, n))
        if mode in ('all', 'methods', 'strings'):
            for idx, acc, co in dms + vms:
                cl, (args, ret), n = dx.method(idx)
                print('    %s %s(%s) -> %s' % ('--' if acc & 2 else '  ', n,
                                               ', '.join(args), ret))
                if mode in ('all', 'strings'):
                    for s in dx.const_strings(co):
                        print('           " %s' % s.replace('\n', '\\n'))
