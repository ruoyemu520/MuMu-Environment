package com.example.myno.clans.modern

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import com.example.myno.clans.hook.Config
import com.example.myno.clans.hook.Feature
import com.example.myno.clans.hook.XLog
import com.example.myno.clans.overlay.ModuleResources
import com.example.myno.clans.overlay.OverlayController
import io.github.libxposed.api.XposedInterface
import io.github.libxposed.api.XposedModule
import java.lang.ref.WeakReference
import java.lang.reflect.Executable

/**
 * 现代管线（io.github.libxposed / API 101+）版的悬浮窗安装器。
 *
 * 逻辑与 [com.example.myno.clans.hook.Installer] 完全一致，区别只在**怎么 hook**：
 *   · legacy：XposedHelpers.findAndHookMethod + XC_MethodHook
 *   · modern：接口给的 Executable + XposedInterface.Hooker（chain.proceed()）
 *
 * 为什么不共用一份：两条管线的 hook 类型根本不同，而且现代管线**禁止**出现
 * de.robv.android.xposed.* 的静态引用，所以宁可各写一份、互相隔离 ——
 * 抽象层一旦不小心引到 legacy 类型，API 102 下整个入口就崩了。
 */
internal object ModernInstaller {

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var controller: OverlayController? = null

    @Volatile
    private var host: WeakReference<Activity>? = null

    @Volatile
    private var toastShown = false

    @Volatile
    private var userClosed = false

    @Volatile
    private var targetActivityClass: Class<*>? = null

    /** onPackageLoaded / onPackageReady / 热重载都可能触发，避免重复挂 */
    @Volatile
    private var installed = false

    fun install(module: XposedModule, cl: ClassLoader) {
        if (installed) return
        installed = true

        targetActivityClass = try {
            cl.loadClass(Config.TARGET_ACTIVITY)
        } catch (t: Throwable) {
            XLog.e("Modern: 没找到 ${Config.TARGET_ACTIVITY}，将只按精确类名识别游戏界面", t)
            null
        }
        targetActivityClass?.let { XLog.i("Modern: 已解析游戏主 Activity: ${it.name}") }

        // ---- Activity 生命周期 → 负责挂上/摘掉悬浮窗 ----
        // 双保险：Instrumentation.callActivityOnResume 框架必调；Activity.onResume
        // 只有子类调了 super 才会走到。两边都挂，onResumed() 内部去重，重复触发无害。
        hookMethod(
            module, cl, "android.app.Instrumentation", "callActivityOnResume",
            arrayOf<Class<*>>(Activity::class.java)
        ) { args, _ ->
            val act = args.getOrNull(0) as? Activity ?: return@hookMethod
            if (Config.isTarget(act.packageName)) safeResume(act)
        }

        hookMethod(
            module, cl, "android.app.Activity", "onResume", emptyArray()
        ) { _, thisObj ->
            val act = thisObj as? Activity ?: return@hookMethod
            if (Config.isTarget(act.packageName)) safeResume(act)
        }

        hookMethod(
            module, cl, "android.app.Instrumentation", "callActivityOnDestroy",
            arrayOf<Class<*>>(Activity::class.java)
        ) { args, _ ->
            val act = args.getOrNull(0) as? Activity ?: return@hookMethod
            if (host?.get() === act) detach()
        }

        hookMethod(
            module, cl, "android.app.Activity", "onDestroy", emptyArray()
        ) { _, thisObj ->
            val act = thisObj as? Activity ?: return@hookMethod
            if (host?.get() === act) detach()
        }

        // 到这里为止，悬浮窗该装的都装完了。
        // ⚠️ 具体游戏功能**没有实现**（原因见 legacy 版 hook/Installer.kt 末尾的说明）：
        //    游戏战斗逻辑在 Cocos2d-x Lua + native 层，Java 层 hook 不到。
        //    要加功能就在本文件末尾挂，格式照抄上面的生命周期 hook，
        //    注意**绝对不能** import de.robv.android.xposed.*。
    }

    /**
     * 挂一个钩子。单个 hook 失败不能连累其它 hook ——
     * 某个机型少一个方法就整个模块装不上，那是最糟的结果。
     */
    private fun hookMethod(
        module: XposedModule,
        cl: ClassLoader,
        className: String,
        methodName: String,
        paramTypes: Array<Class<*>>,
        block: (List<Any?>, Any?) -> Unit
    ) {
        try {
            val cls = Class.forName(className, false, cl)
            val m: Executable = if (paramTypes.isEmpty()) {
                cls.getDeclaredMethod(methodName)
            } else {
                cls.getDeclaredMethod(methodName, *paramTypes)
            }
            module.hook(m).intercept(ModernAfterHooker(block))
            XLog.i("Modern: 已 hook $className.$methodName")
        } catch (t: Throwable) {
            XLog.e("Modern: hook 失败（跳过）: $className.$methodName", t)
        }
    }

    private fun safeResume(activity: Activity) {
        try {
            onResumed(activity)
        } catch (t: Throwable) {
            XLog.e("Modern: 挂载悬浮窗失败", t)
        }
    }

    private fun onResumed(activity: Activity) {
        val ctx: Context = activity.applicationContext ?: activity

        showInjectToastOnce(ctx)

        // 用户点了面板里的「关闭悬浮窗」：本进程内别再自动挂回来。
        // 标记在 detach()（宿主 Activity 真正被销毁）时清除，退出游戏再进就恢复。
        if (userClosed) return

        // 只挂在游戏主 Activity 上，别跑到登录、支付、WebView 那些 SDK 页面上
        if (!isGameActivity(activity)) return
        if (controller?.isAttached == true && host?.get() === activity) return

        detach()

        // 优先 decor（免权限）；失败才退到系统悬浮窗兜底。
        // 「悬浮窗模式」设置项已删除，这里不再读任何配置（与 legacy 版一致）。
        if (!attachDecor(activity, ctx)) {
            XLog.i("Modern: decor 挂载失败，回退到 window 模式")
            attachWindow(ctx)
        }
    }

    /**
     * 是不是「游戏主体 Activity」。光比类名不够稳：渠道包/SDK 常常继承一层再交给
     * AppActivity 渲染，类名就不是 org.cocos2dx.lua.AppActivity 了。所以先拿到目标类
     * 用 isInstance 覆盖子类；拿不到类时退回比类名。
     */
    private fun isGameActivity(activity: Activity): Boolean {
        val name = activity.javaClass.name
        if (name == Config.TARGET_ACTIVITY) return true
        val cls = targetActivityClass
        if (cls != null) return cls.isInstance(activity)
        return false
    }

    /** 免权限方案：塞进游戏 Activity 的 decorView */
    private fun attachDecor(activity: Activity, ctx: Context): Boolean {
        val res = ModuleResources.resolve(ctx)
        val c = OverlayController.forDecor(activity, res)
        if (c == null) {
            XLog.e("Modern: forDecor 返回 null（decorView 不是 ViewGroup）")
            return false
        }
        c.onUserClosed = { userClosed = true }
        controller = c
        host = WeakReference(activity)
        XLog.i("Modern: 悬浮窗已挂到 decorView: ${activity.javaClass.name}")
        return true
    }

    /** 兜底方案：系统悬浮窗，需要目标游戏自己有悬浮窗权限 */
    private fun attachWindow(ctx: Context) {
        if (!hasOverlayPermission(ctx)) {
            XLog.e(
                "Modern: window 模式需要悬浮窗权限，但 ${ctx.packageName} 没有。"
                        + "请给游戏开「显示在其他应用上层」，或把模式设回 decor/auto"
            )
            return
        }
        val res = ModuleResources.resolve(ctx)
        val c = OverlayController.forWindow(ctx, res)
        c.onUserClosed = { userClosed = true }
        controller = c
        host = null
        XLog.i("Modern: 悬浮窗已用 WindowManager 挂载")
    }

    private fun detach() {
        try {
            controller?.destroy()
        } catch (t: Throwable) {
            XLog.e("Modern: 移除悬浮窗失败", t)
        }
        controller = null
        host = null
        userClosed = false
    }

    private fun hasOverlayPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)

    /** 注入成功给个可见反馈，方便确认模块到底有没有生效 */
    private fun showInjectToastOnce(ctx: Context) {
        if (toastShown) return
        toastShown = true
        if (!Config.isOn(ctx, Feature.INJECT_TOAST)) return
        try {
            main.post {
                try {
                    Toast.makeText(ctx, "Clans 模块已注入（API 102）", Toast.LENGTH_SHORT).show()
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        }
    }
}

/**
 * 现代 Hooker：先 chain.proceed() 再回调，语义等价于 legacy 的 afterHookedMethod。
 * API 102 已经不再要求 @XposedHooker 注解（那个注解在 io.github.libxposed:api:102 里已删除）。
 */
internal class ModernAfterHooker(
    private val block: (List<Any?>, Any?) -> Unit
) : XposedInterface.Hooker {

    override fun intercept(chain: XposedInterface.Chain): Any? {
        val result = chain.proceed()
        try {
            block(chain.args, chain.thisObject)
        } catch (t: Throwable) {
            XLog.e("Modern: hook 回调抛异常（已吞掉，不影响游戏）", t)
        }
        return result
    }
}
