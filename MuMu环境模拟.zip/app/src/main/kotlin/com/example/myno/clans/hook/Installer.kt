package com.example.myno.clans.hook

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import com.example.myno.clans.overlay.ModuleResources
import com.example.myno.clans.overlay.OverlayController
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.ref.WeakReference

/**
 * 把悬浮窗装进目标游戏进程。
 *
 * 两种挂载方式：
 *  1) decor 模式（默认 / auto）：直接 addView 到游戏 Activity 的 decorView。
 *     **不需要 SYSTEM_ALERT_WINDOW**。这对 LSPatch 本地模式特别关键 ——
 *     被 patch 的游戏一般并没有悬浮窗权限，走系统悬浮窗会直接 BadTokenException。
 *     Cocos2d-x 的渲染面是 SurfaceView，默认位于窗口图层**之下**，
 *     所以普通 View 加到 decorView 上正好画在游戏画面之上，且不碰游戏渲染。
 *  2) window 模式（兜底）：走 WindowManager 的 TYPE_APPLICATION_OVERLAY，
 *     需要游戏自己拿到「显示在其他应用上层」权限。
 */
object Installer {

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var controller: OverlayController? = null

    @Volatile
    private var host: WeakReference<Activity>? = null

    @Volatile
    private var toastShown = false

    /** 用户主动关闭过悬浮窗（见 detach() 里的清除逻辑） */
    @Volatile
    private var userClosed = false

    /** 游戏主 Activity 的 Class，install 时解析一次（覆盖子类用），可能为 null */
    @Volatile
    private var targetActivityClass: Class<*>? = null

    fun install(lpparam: XC_LoadPackage.LoadPackageParam) {
        val cl = lpparam.classLoader

        val target = try {
            XposedHelpers.findClassIfExists(Config.TARGET_ACTIVITY, cl)
        } catch (t: Throwable) {
            XLog.e("解析 ${Config.TARGET_ACTIVITY} 抛异常", t)
            null
        }
        targetActivityClass = target
        if (target == null) {
            XLog.e("没找到 ${Config.TARGET_ACTIVITY}，将只按精确类名识别游戏界面")
        } else {
            XLog.i("已解析游戏主 Activity: ${target.name}")
        }

        // ---- Activity 生命周期 → 负责挂上/摘掉悬浮窗 ----
        //
        // 双保险：Instrumentation.callActivityOnXxx 是框架对每个 Activity 必调的，
        // 而 Activity.onXxx 只有子类调了 super 才会走到。有些游戏的 Activity
        // 重写了 onResume 就是不调 super，只挂后者会直接失效。
        // 两边都挂，onResumed() 内部有去重判断，重复触发无害。
        hook(
            cl, "android.app.Instrumentation", "callActivityOnResume",
            Activity::class.java,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val act = param.args.getOrNull(0) as? Activity ?: return
                    if (!Config.isTarget(act.packageName)) return
                    safeResume(act)
                }
            }
        )

        hook(
            cl, "android.app.Activity", "onResume",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val act = param.thisObject as? Activity ?: return
                    if (!Config.isTarget(act.packageName)) return
                    safeResume(act)
                }
            }
        )

        hook(
            cl, "android.app.Instrumentation", "callActivityOnDestroy",
            Activity::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val act = param.args.getOrNull(0) as? Activity ?: return
                    if (host?.get() === act) detach()
                }
            }
        )

        hook(
            cl, "android.app.Activity", "onDestroy",
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val act = param.thisObject as? Activity ?: return
                    if (host?.get() === act) detach()
                }
            }
        )

        // 到这里为止，悬浮窗该装的都装完了。
        // 面板目前只有「MuMu 环境」状态行和设置页，没有其它占位开关。
        //    要加功能，就在本文件末尾挂 hook，格式照抄上面的生命周期 hook。
    }

    /**
     * 单个 hook 失败不能连累其它 hook。
     * findAndHookMethod 在「类或方法不存在」时会抛，所以必须逐个包住 ——
     * 否则某个机型上少一个方法，整个模块就装不上了。
     */
    private fun hook(
        cl: ClassLoader,
        className: String,
        methodName: String,
        vararg params: Any
    ) {
        try {
            XposedHelpers.findAndHookMethod(className, cl, methodName, *params)
            XLog.i("已 hook $className.$methodName")
        } catch (t: Throwable) {
            XLog.e("hook 失败（跳过）: $className.$methodName", t)
        }
    }

    private fun safeResume(activity: Activity) {
        try {
            onResumed(activity)
        } catch (t: Throwable) {
            XLog.e("挂载悬浮窗失败", t)
        }
    }

    private fun onResumed(activity: Activity) {
        val ctx: Context = activity.applicationContext ?: activity

        showInjectToastOnce(ctx)

        // 用户点了面板里的「关闭悬浮窗」：本进程内别再自动挂回来。
        // 这个标记在 detach()（宿主 Activity 真正被销毁）时清除，
        // 所以退出游戏再进就恢复了。
        if (userClosed) return

        // 只挂在游戏主 Activity 上，别跑到登录、支付、WebView 那些 SDK 页面上
        if (!isGameActivity(activity)) return

        // 已经挂在同一个 Activity 上就不重复挂
        if (controller?.isAttached == true && host?.get() === activity) return

        detach()

        // 优先 decor（免权限）；失败才退到系统悬浮窗兜底。
        // 「悬浮窗模式」设置项已删除，这里不再读任何配置。
        if (!attachDecor(activity, ctx)) {
            XLog.i("decor 挂载失败，回退到 window 模式")
            attachWindow(ctx)
        }
    }

    /**
     * 是不是「游戏主体 Activity」。
     *
     * 光比类名不够稳：渠道包/SDK 常常继承一层再交给 AppActivity 渲染，
     * 那样类名就不是 org.cocos2dx.lua.AppActivity 了，模块会静默不挂。
     * 所以先拿到目标类，用 isInstance 覆盖子类；拿不到类时再退回比类名。
     */
    private fun isGameActivity(activity: Activity): Boolean {
        val name = activity.javaClass.name
        if (name == Config.TARGET_ACTIVITY) return true
        val cls = targetActivityClass
        if (cls != null) return cls.isInstance(activity)
        // 目标类没找着（被改名/换包）：只认精确类名，绝不乱挂
        return false
    }

    /** 免权限方案：塞进游戏 Activity 的 decorView */
    private fun attachDecor(activity: Activity, ctx: Context): Boolean {
        val res = ModuleResources.resolve(ctx)
        val c = OverlayController.forDecor(activity, res)
        if (c == null) {
            XLog.e("forDecor 返回 null（decorView 不是 ViewGroup）")
            return false
        }
        c.onUserClosed = { userClosed = true }
        controller = c
        host = WeakReference(activity)
        XLog.i("悬浮窗已挂到 decorView: ${activity.javaClass.name}")
        return true
    }

    /** 兜底方案：系统悬浮窗，需要目标应用有悬浮窗权限 */
    private fun attachWindow(ctx: Context) {
        if (!hasOverlayPermission(ctx)) {
            XLog.e(
                "window 模式需要悬浮窗权限，但 ${ctx.packageName} 没有。"
                        + "请给游戏开「显示在其他应用上层」，或把模式设回 decor/auto"
            )
            return
        }
        val res = ModuleResources.resolve(ctx)
        val c = OverlayController.forWindow(ctx, res)
        c.onUserClosed = { userClosed = true }
        controller = c
        host = null
        XLog.i("悬浮窗已用 WindowManager 挂载")
    }

    private fun detach() {
        try {
            controller?.destroy()
        } catch (t: Throwable) {
            XLog.e("移除悬浮窗失败", t)
        }
        controller = null
        host = null
        // 宿主 Activity 真的没了 → 下次进游戏重新挂，用户关闭的意图不再保留
        userClosed = false
    }

    private fun hasOverlayPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(ctx)

    /** 注入成功给个可见反馈，方便确认模块到底有没有生效 */
    private fun showInjectToastOnce(ctx: Context) {
        if (toastShown) return
        toastShown = true
        if (!Config.isOn(ctx, Feature.INJECT_TOAST)) return
        try {
            main.post {
                try {
                    Toast.makeText(ctx, "Clans 模块已注入", Toast.LENGTH_SHORT).show()
                } catch (_: Throwable) {
                }
            }
        } catch (_: Throwable) {
        }
    }
}
